
import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Box,
  Button,
  Divider,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";

import AddCircleIcon from "@mui/icons-material/AddCircle";
import DeleteIcon from "@mui/icons-material/Delete";
import VisibilityIcon from "@mui/icons-material/Visibility";
import SaveIcon from "@mui/icons-material/Save";
import BuildIcon from "@mui/icons-material/Build";
import InstrumentList from "../MaterialInspection/InstrumentList";

function DimensionalForm({ selectedRow = [], sampleCount = 15, onSummaryChange }) {
  const [generalTolerance, setGeneralTolerance] = useState(null);
  const [rows, setRows] = useState([]);
  const [instrumentOptions, setInstrumentOptions] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [showInstrumentTable, setShowInstrumentTable] = useState(false);

  // ⭐ Fetch General Tolerance
  useEffect(() => {
    axios
      .get("http://192.168.0.149:8000/dimensionreport")
      .then((res) => setGeneralTolerance(res.data.Tolerance))
      .catch((err) => console.error("Failed to load tolerance", err));
  }, []);

  // ⭐ Fetch Instruments
  useEffect(() => {
    axios
      .get("http://192.168.0.149:8000/Instrumentdetails")
      .then((res) => setInstrumentOptions(res.data))
      .catch((err) => console.error("Instrument fetch error", err));
  }, []);

  // ⭐ Load Dimension Rows From API (selectedRow)
  useEffect(() => {
    if (Array.isArray(selectedRow) && selectedRow.length > 0) {
      const formattedRows = selectedRow.map((item, index) => ({
        slno: index + 1,
        instrumentUsed: item.Measuring_Instr_Id || "",
        basicDimension: item.Basic_Dimension || "",
        min: item.Min || "",
        max: item.Max || "",
        observed: [
          item.Sample_1 || "",
          item.Sample_2 || "",
          item.Sample_3 || "",
          item.Sample_4 || "",
          item.Sample_5 || "",
          item.Sample_6 || "",
          item.Sample_7 || "",
          item.Sample_8 || "",
          item.Sample_9 || "",
          item.Sample_10 || "",
          item.Sample_11 || "",
          item.Sample_12 || "",
          item.Sample_13 || "",
          item.Sample_14 || "",
          item.Sample_15 || "",
        ],
        refNo: item.Reference_No,
        id: item.id,
      }));

      setRows(formattedRows);
    }
  }, [selectedRow]);

  // ⭐ Maintain Summary
  useEffect(() => {
    if (onSummaryChange) onSummaryChange(getSummary());
  }, [rows]);

  // ⭐ Updates rows when sample count changes
  useEffect(() => {
    setRows((prev) =>
      prev.map((r) => ({
        ...r,
        observed: Array(sampleCount)
          .fill("")
          .map((_, i) => r.observed[i] || ""),
      }))
    );
  }, [sampleCount]);

  const handleChange = (index, field, value, obsIndex = null) => {
    const regex = /^\d*\.?\d{0,2}$/;

    setRows((prev) => {
      const newRows = [...prev];
      const row = { ...newRows[index] };

      if (field === "instrumentUsed") {
        // Instrument dropdown stores ID, NOT name
        row.instrumentUsed = value;
      } else if (field === "basicDimension") {
        if (value === "" || regex.test(value)) {
          row.basicDimension = value;

          if (value && generalTolerance != null) {
            const base = parseFloat(value);
            row.min = (base - generalTolerance).toFixed(2);
            row.max = (base + generalTolerance).toFixed(2);
          }
        }
      } else if (field === "observed" && obsIndex != null) {
        if (value === "" || regex.test(value)) {
          row.observed[obsIndex] = value;
        }
      }

      newRows[index] = row;
      return newRows;
    });
  };

  // const addRow = (i) => {
  //   const updated = [...rows];
  //   updated.splice(i + 1, 0, {
  //     slno: rows.length + 1,
  //     instrumentUsed: "",
  //     basicDimension: "",
  //     min: "",
  //     max: "",
  //     observed: Array(sampleCount).fill(""),
  //   });

  //   updated.forEach((r, idx) => (r.slno = idx + 1));
  //   setRows(updated);
  // };

  // const deleteRow = (i) => {
  //   if (rows.length === 1) return;

  //   const updated = rows.filter((_, index) => index !== i);
  //   updated.forEach((r, idx) => (r.slno = idx + 1));
  //   setRows(updated);
  // };

  // ⭐ SAVE DATA
  const handleSave = async () => {
    const payload = rows.map((r) => ({
      id: r.id || 0,
      Basic_Dimension: r.basicDimension,
      Measuring_Instr_Id: r.instrumentUsed, // Backend store ID
      Tolerance: generalTolerance,
      Min: r.min,
      Max: r.max,
      Reference_No: r.refNo || selectedRow[0]?.Reference_No,
      Sample_1: r.observed[0],
      Sample_2: r.observed[1],
      Sample_3: r.observed[2],
      Sample_4: r.observed[3],
      Sample_5: r.observed[4],
      Sample_6: r.observed[5],
      Sample_7: r.observed[6],
      Sample_8: r.observed[7],
      Sample_9: r.observed[8],
      Sample_10: r.observed[9],
      Sample_11: r.observed[10],
      Sample_12: r.observed[11],
      Sample_13: r.observed[12],
      Sample_14: r.observed[13],
      Sample_15: r.observed[14],
    }));

    console.log("Saving Dimensions:", payload);

    try {
      await axios.post("http://192.168.0.149:8000/savedimensiondata", payload);
      alert("Dimension Data Saved Successfully");
    } catch (error) {
      console.error("Save Error", error);
      alert("Failed to save dimension data.");
    }
  };

  const getInspectionResults = () => {
    const results = [];

    rows.forEach((row) => {
      row.observed.forEach((val, i) => {
        if (!val) return;

        const num = parseFloat(val);
        const status = num >= parseFloat(row.min) && num <= parseFloat(row.max) ? "Accepted" : "Rejected";

        results.push({
          sample: `Row ${row.slno} - Sample ${i + 1}`,
          value: num,
          status,
        });
      });
    });

    return results;
  };

  const getSummary = () => {
    const result = getInspectionResults();
    return {
      accepted: result.filter((r) => r.status === "Accepted").length,
      rejected: result.filter((r) => r.status === "Rejected").length,
    };
  };

  const isRejected = (val, min, max) => {
    if (!val) return false;
    const n = parseFloat(val);
    return n < parseFloat(min) || n > parseFloat(max);
  };

  return (
    <Grid item xs={12}>
      <Divider sx={{ my: 1 }} />

      <Box p={2}>
        <Typography align="center" variant="h6" sx={{ fontWeight: "bold", textDecoration: "underline" }}>
          DIMENSIONAL INSPECTION REPORT
        </Typography>

        {/* <Typography sx={{ fontWeight: "bold", mt: 1 }}>
          General Tolerance: {generalTolerance !== null ? `± ${generalTolerance} mm` : "Loading..."}
        </Typography> */}

        <Box
          sx={{
            display: "flex",
            justifyContent: "right",
            gap: 2,
            mt: 2,
          }}
        >
          {/* Add Row */}
          {/* <Button */}
          <AddCircleIcon

            variant="contained"
            color="success"
            // width="14rem"
            // sx={{width: "12rem"}}
            onClick={() => {
              const newRow = {
                slno: rows.length + 1,
                instrument: "",
                basicDimension: "",
                min: "",
                max: "",
                observed: Array(sampleCount).fill(""),
              };

              const updated = [...rows, newRow];
              setRows(updated);
            }}
          />
            {/* Add Dimension */}
          {/* </Button> */}

          {/* Delete Last Row */}
          {/* <Button */}
          <DeleteIcon
            variant="contained"
            color="error"
            // sx={{width: "12rem"}}

            disabled={rows.length === 1}
            onClick={() => {
              if (rows.length === 1) return;
              const updated = rows.slice(0, -1);
              setRows(updated);
            }}
          />
            {/* Delete Dimension
          </Button> */}

          {/* Show / Hide Results */}
          <Button
            variant="contained"
            color="primary"
            sx={{width: "10rem"}}

            onClick={() => setShowResults(prev => !prev)}
          >
            {showResults ? "Hide Results" : "Show Results"}
          </Button>
        </Box>

        {/* MAIN TABLE */}
        <TableContainer component={Paper} sx={{ border: "1px solid black", mt: 2 , borderRadius: "12px"}}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ border: "1px solid black" }}>SL</TableCell>
                <TableCell sx={{ border: "1px solid black" }}>Instrument Used</TableCell>
                <TableCell sx={{ border: "1px solid black" }}>Basic Dimension</TableCell>
                <TableCell sx={{ border: "1px solid black" }}>Min</TableCell>
                <TableCell sx={{ border: "1px solid black" }}>Max</TableCell>
                

                {Array(sampleCount)
                  .fill(0)
                  .map((_, i) => (
                    <TableCell key={i} sx={{ border: "1px solid black", textAlign: "center" }}>
                      {i + 1}
                    </TableCell>
                  ))}

                {/* <TableCell sx={{ border: "1px solid black" }}>Actions</TableCell> */}
              </TableRow>
            </TableHead>

            <TableBody>
              {rows.map((row, i) => (
                <TableRow key={i}>
                  <TableCell sx={{ border: "1px solid black" }}>{row.slno}</TableCell>

                  {/* ⭐ Instrument Dropdown (shows name but stores ID) */}
                  <TableCell sx={{ border: "1px solid black" }}>
                    <TextField
                      select
                      variant="standard"
                      fullWidth
                      value={row.instrumentUsed}
                      onChange={(e) => handleChange(i, "instrumentUsed", e.target.value)}
                      SelectProps={{ native: true }}
                    >
                      <option value="">Select</option>
                      {instrumentOptions.map((inst) => (
                        <option key={inst.id} value={inst.id}>
                          {inst.Type}
                        </option>
                      ))}
                    </TextField>
                  </TableCell>

                  <TableCell sx={{ border: "1px solid black" }}>
                    <TextField
                      variant="standard"
                      fullWidth
                      value={row.basicDimension}
                      onChange={(e) => handleChange(i, "basicDimension", e.target.value)}
                    />
                  </TableCell>

                  <TableCell sx={{ border: "1px solid black" }}>{row.min}</TableCell>
                  <TableCell sx={{ border: "1px solid black" }}>{row.max}</TableCell>

                  {row.observed.map((val, j) => (
                    <TableCell
                      key={j}
                      sx={{
                        border: "1px solid black",
                        backgroundColor: isRejected(val, row.min, row.max) ? "#ffcccc" : "white",
                      }}
                    >
                      <TextField
                        variant="standard"
                        fullWidth
                        value={val}
                        onChange={(e) => handleChange(i, "observed", e.target.value, j)}
                      />
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>


                {/* Results Table */}
                {showResults && (
          <Box mt={4}>
            <Typography variant="h6" sx={{ fontWeight: "bold", mb: 1 ,textAlign:'center', fontFamily: 'Times New Roman', fontSize:18}}>
              Inspection Results
            </Typography>
            <TableContainer component={Paper} sx={{ border: "1px solid black" }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}>Sample</TableCell>
                    <TableCell sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}>Basic Dimension</TableCell>
                    <TableCell sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}>Observed Value</TableCell>
                    <TableCell sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}>Result</TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {getInspectionResults().map((res, idx) => (
                    <React.Fragment key={idx}>
                      {res.basicDimensions.map((dim, dIdx) => (
                        <TableRow key={`${idx}-${dIdx}`}>

                          {/* MERGED SAMPLE CELL */}
                          {dIdx === 0 && (
                            <TableCell
                              rowSpan={res.basicDimensions.length}
                              sx={{
                                border: "1px solid black",
                                textAlign: "center",
                                verticalAlign: "middle",
                                fontWeight: "bold"
                              }}
                            >
                              {res.sample}
                            </TableCell>
                          )}

                          {/* Basic Dimension */}
                          <TableCell sx={{ border: "1px solid black", textAlign: "center" }}>
                            {dim}
                          </TableCell>

                          {/* Observed Value */}
                          <TableCell sx={{ border: "1px solid black", textAlign: "center" }}>
                            {res.observedValues[dIdx]}
                          </TableCell>

                          {/* MERGED RESULT CELL */}
                          {dIdx === 0 && (
                            <TableCell
                              rowSpan={res.basicDimensions.length}
                              sx={{
                                border: "1px solid black",
                                textAlign: "center",
                                verticalAlign: "middle",
                                color: res.status === "Rejected" ? "red" : "green",
                                fontWeight: "bold",
                              }}
                            >
                              {res.status}
                            </TableCell>
                          )}

                        </TableRow>
                      ))}
                    </React.Fragment>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            

          </Box>
        )}

 
      </Box>
    </Grid>
  );
}

export default DimensionalForm;


