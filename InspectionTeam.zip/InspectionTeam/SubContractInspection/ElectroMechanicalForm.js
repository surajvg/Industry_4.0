import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Box,
  Button,
  Card,
  Divider,
  Grid,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import VisibilityIcon from "@mui/icons-material/Visibility";
import SaveIcon from "@mui/icons-material/Save";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import InstrumentList from "../MaterialInspection/InstrumentList";

// ==========================================================
// ELECTROMECHANICAL FORM (PHYSICAL + ELECTRICAL + INSTRUMENTS)
// ==========================================================
function ElectromechanicalForm({
  sampleCount = 15,
  onPhysicalSummaryChange,
  onElectricalSummaryChange,
  selectedRow = [],
}) {
  const TOLERANCE = 0.3;

  // ---------------- PHYSICAL SECTION STATE ----------------
  const [physicalRows, setPhysicalRows] = useState([]);
  const [physicalCommon, setPhysicalCommon] = useState({
    dimensionParameter: "",
    unit: "",
    remarks: "",
    markingOnMaterial: "",
    visualInspection: "",
    coc: "",
    testReports: "",
    qtyReceived: "",
    inspectionRemarks: "",
  });
  const [showPhysicalResults, setShowPhysicalResults] = useState(false);

  // ---------------- ELECTRICAL SECTION STATE ----------------
  const [electricalRows, setElectricalRows] = useState([]);
  const [electricalCommon, setElectricalCommon] = useState({
    dimensionParameter: "",
    unit: "",
    remarks: "",
    markingOnMaterial: "",
    visualInspection: "",
    coc: "",
    testReports: "",
    qtyReceived: "",
    inspectionRemarks: "",
  });
  const [showElectricalResults, setShowElectricalResults] = useState(false);

  // Electrical measurements metadata
  const [selectedMeasurement, setSelectedMeasurement] = useState("");
  const measurements = [
    { value: "resistance", label: "Resistance - Ω", symbol: "Ω" },
    { value: "capacitance", label: "Capacitance - F", symbol: "F" },
    { value: "conductance", label: "Conductance - S", symbol: "S" },
    { value: "voltage", label: "Voltage - V", symbol: "V" },
    { value: "current", label: "Current - A", symbol: "A" },
    { value: "rotation", label: "Direction of Rotation -↻/↺", symbol: "↻/↺" },
  ];

  const [physicalBasicDimensions, setPhysicalBasicDimensions] = useState([]);
  const [electricalBasicDimensions, setElectricalBasicDimensions] = useState([]);

  // ---------------- LOADING DIMENSION ROWS FROM API ----------------
  useEffect(() => {
    if (Array.isArray(selectedRow) && selectedRow.length > 0) {
      const formattedRows = selectedRow.map((item, index) => ({
        slno: index + 1,
        Dimension_Name: item.Dimension_Name,
        basicDimension: item.Basic_Dimension || "",
        min: item.Min || "",
        max: item.Max || "",
        observed: [
          item.Sample_1 || "",
          item.Sample_2 || "",
          item.Sample_3 || "",
          item.Sample_4 || "",
          item.Sample_5 || "",
          item.Sample_6 || "",
          item.Sample_7 || "",
          item.Sample_8 || "",
          item.Sample_9 || "",
          item.Sample_10 || "",
          item.Sample_11 || "",
          item.Sample_12 || "",
          item.Sample_13 || "",
          item.Sample_14 || "",
          item.Sample_15 || "",
        ],
        refNo: item.Reference_No,
        Dimension_Report_Id: item.Dimension_Report_Id,
        dimensionParameter: item.Dimension_Name || "",
        remarks: item.Remarks || "",
      }));

      // Load same base rows into both sections (as your previous code did)
      setPhysicalRows(formattedRows);
      setElectricalRows(formattedRows);
    }
  }, [selectedRow]);

  // ---------------- BASIC DIMENSIONS DUMMY DATA ----------------
  useEffect(() => {
    setPhysicalBasicDimensions([
      { instrumentName: "Vernier Caliper", dimension: 50.0 },
      { instrumentName: "Scale", dimension: 75.0 },
      { instrumentName: "Tape", dimension: 25.0 },
    ]);

    setElectricalBasicDimensions([
      { dimension: 25.0 },
      { dimension: 50.0 },
      { dimension: 75.0 },
    ]);
  }, []);

  // ---------------- SAMPLE ARRAY SIZE SYNC (PHYSICAL) ----------------
  useEffect(() => {
    setPhysicalRows((prev) =>
      prev.map((r) => ({
        ...r,
        observed: Array(sampleCount)
          .fill("")
          .map((_, i) => r.observed[i] || ""),
      }))
    );
  }, [sampleCount]);

  // ---------------- SAMPLE ARRAY SIZE SYNC (ELECTRICAL) ----------------
  useEffect(() => {
    setElectricalRows((prev) =>
      prev.map((r) => ({
        ...r,
        observed: Array(sampleCount)
          .fill("")
          .map((_, i) => r.observed[i] || ""),
      }))
    );
  }, [sampleCount]);

  // ==========================================================
  // UTILITIES - PHYSICAL
  // ==========================================================

  const handlePhysicalChange = (index, field, value, obsIndex = null) => {
    const regex = /^\d*\.?\d{0,2}$/;
    setPhysicalRows((prev) => {
      const newRows = [...prev];
      const row = { ...newRows[index] };

      if (field === "basicDimension") {
        if (value === "" || regex.test(value)) {
          row.basicDimension = value;
          if (value) {
            const numVal = parseFloat(value);
            row.min = (numVal - TOLERANCE).toFixed(2);
            row.max = (numVal + TOLERANCE).toFixed(2);
          } else {
            row.min = "";
            row.max = "";
          }
        }
      } else if (field === "observed" && obsIndex !== null) {
        if (value === "" || regex.test(value)) {
          const updatedObserved = [...row.observed];
          updatedObserved[obsIndex] = value;
          row.observed = updatedObserved;
        }
      } else if (field === "dimensionParameter" || field === "remarks") {
        row[field] = value;
      } else {
        if (value === "" || regex.test(value)) {
          row[field] = value;
        }
      }

      newRows[index] = row;
      return newRows;
    });
  };

  const validatePhysicalSample = (sampleIndex) => {
    for (let row of physicalRows) {
      const val = parseFloat(row.observed[sampleIndex]);
      const min = parseFloat(row.min);
      const max = parseFloat(row.max);
      if (isNaN(val) || val < min || val > max) {
        return false;
      }
    }
    return true;
  };

  const getPhysicalInspectionResults = () => {
    const results = [];

    for (let s = 0; s < sampleCount; s++) {
      let hasAnyValue = false;
      let sampleStatus = "Accepted";

      const dimensionList = [];
      const observedList = [];

      for (let r = 0; r < physicalRows.length; r++) {
        const row = physicalRows[r];
        const basicD = row.basicDimension;
        const valStr = row.observed[s];

        if (valStr === "" || basicD === "") continue;

        hasAnyValue = true;

        const val = parseFloat(valStr);
        const min = parseFloat(row.min);
        const max = parseFloat(row.max);

        dimensionList.push(basicD);
        observedList.push(val);

        if (isNaN(val) || val < min || val > max) {
          sampleStatus = "Rejected";
        }
      }

      if (hasAnyValue) {
        results.push({
          sample: s + 1,
          basicDimensions: dimensionList,
          observedValues: observedList,
          status: sampleStatus,
        });
      }
    }

    return results;
  };

  const getPhysicalSummary = () => {
    const results = getPhysicalInspectionResults();
    let accepted = 0;
    let rejected = 0;
    results.forEach((r) => {
      r.status === "Accepted" ? accepted++ : rejected++;
    });
    return { accepted, rejected };
  };

  const getPhysicalQtyInspected = () => {
    let count = 0;
    for (let s = 0; s < sampleCount; s++) {
      let sampleHasValue = false;
      for (let r = 0; r < physicalRows.length; r++) {
        if (physicalRows[r].observed[s] !== "") {
          sampleHasValue = true;
          break;
        }
      }
      if (sampleHasValue) count++;
    }
    return count;
  };

  const isRejectedValuePhysical = (val, min, max) => {
    if (val === "") return false;
    const numVal = parseFloat(val);
    return numVal < parseFloat(min) || numVal > parseFloat(max);
  };

  useEffect(() => {
    if (onPhysicalSummaryChange) {
      onPhysicalSummaryChange(getPhysicalSummary());
    }
  }, [physicalRows]); // eslint-disable-line react-hooks/exhaustive-deps

  const buildPhysicalPayload = () => {
    return {
      Reference_No: physicalRows[0]?.refNo || "",

      Common: {
        Dimension_Parameter: physicalCommon.dimensionParameter || "",
        Unit: physicalCommon.unit || "",
        Remarks: physicalCommon.remarks || "",
        Marking_On_Material: physicalCommon.markingOnMaterial || "",
        Visual_Inspection_Report: physicalCommon.visualInspection || "",
        Electrical_Inspection_Remark: "",
        Electrical_Parameter: "",
        Functional: "",
        Dimensions: "",
        Visual_Inspection: "",
        COC: physicalCommon.coc || "",
        Test_Reports: physicalCommon.testReports || "",
        Imported_Doc_Received: "",
        Malware_Free_Cert: "",
        FOD_Check: "",
        Counterfeit_Checked: "",
        MFG_Date: null,
        Exp_Date: null,
        Qty_Received: physicalCommon.qtyReceived || "",
        Qty_Inspected: getPhysicalQtyInspected(),
        Qty_Accepted: getPhysicalSummary().accepted || "",
        Qty_Rejected: getPhysicalSummary().rejected || "",
        Inspection_Remarks: physicalCommon.inspectionRemarks || "",
      },

      Dimensions: physicalRows.map((r) => ({
        Report_Id: r.Dimension_Report_Id,
        Dimension_Name: r.Dimension_Name,
        Samples: r.observed
          .map((value, index) => {
            if (!value) return null;

            const num = parseFloat(value);
            const min = parseFloat(r.min);
            const max = parseFloat(r.max);

            const status =
              !isNaN(num) && num >= min && num <= max ? "Accepted" : "Rejected";

            return {
              Sample_No: index + 1,
              Value: num,
              Status: status,
            };
          })
          .filter((x) => x !== null),
      })),
    };
  };

  // ==========================================================
  // UTILITIES - ELECTRICAL
  // ==========================================================

  const handleMeasurementChange = (event) => {
    setSelectedMeasurement(event.target.value);
  };

  const handleElectricalChange = (index, field, value, obsIndex = null) => {
    const regex = /^\d*\.?\d{0,2}$/;
    setElectricalRows((prev) => {
      const newRows = [...prev];
      const row = { ...newRows[index] };

      if (field === "basicDimension") {
        if (value === "" || regex.test(value)) {
          row.basicDimension = value;
          if (value) {
            const numVal = parseFloat(value);
            row.min = (numVal - TOLERANCE).toFixed(2);
            row.max = (numVal + TOLERANCE).toFixed(2);
          } else {
            row.min = "";
            row.max = "";
          }
        }
      } else if (field === "observed" && obsIndex !== null) {
        if (value === "" || regex.test(value)) {
          const updatedObserved = [...row.observed];
          updatedObserved[obsIndex] = value;
          row.observed = updatedObserved;
        }
      } else {
        if (value === "" || regex.test(value)) {
          row[field] = value;
        }
      }

      newRows[index] = row;
      return newRows;
    });
  };

  const validateElectricalSample = (sampleIndex) => {
    for (let row of electricalRows) {
      const val = parseFloat(row.observed[sampleIndex]);
      const min = parseFloat(row.min);
      const max = parseFloat(row.max);

      if (isNaN(val) || val < min || val > max) {
        return false;
      }
    }
    return true;
  };

  const getElectricalInspectionResults = () => {
    const results = [];

    for (let s = 0; s < sampleCount; s++) {
      let hasAnyValue = false;
      let sampleStatus = "Accepted";

      const dimensionList = [];
      const observedList = [];

      for (let r = 0; r < electricalRows.length; r++) {
        const row = electricalRows[r];
        const basicD = row.basicDimension;
        const valStr = row.observed[s];

        if (valStr === "" || basicD === "") continue;

        hasAnyValue = true;

        const val = parseFloat(valStr);
        const min = parseFloat(row.min);
        const max = parseFloat(row.max);

        dimensionList.push(basicD);
        observedList.push(val);

        if (isNaN(val) || val < min || val > max) {
          sampleStatus = "Rejected";
        }
      }

      if (hasAnyValue) {
        results.push({
          sample: s + 1,
          basicDimensions: dimensionList,
          observedValues: observedList,
          status: sampleStatus,
        });
      }
    }

    return results;
  };

  const getElectricalSummary = () => {
    const results = getElectricalInspectionResults();
    let accepted = 0;
    let rejected = 0;
    results.forEach((r) => {
      r.status === "Accepted" ? accepted++ : rejected++;
    });
    return { accepted, rejected };
  };

  const getElectricalQtyInspected = () => {
    let count = 0;
    for (let s = 0; s < sampleCount; s++) {
      let sampleHasValue = false;
      for (let r = 0; r < electricalRows.length; r++) {
        if (electricalRows[r].observed[s] !== "") {
          sampleHasValue = true;
          break;
        }
      }
      if (sampleHasValue) count++;
    }
    return count;
  };

  const isRejectedValueElectrical = (val, min, max) => {
    if (val === "") return false;
    const numVal = parseFloat(val);
    return numVal < parseFloat(min) || numVal > parseFloat(max);
  };

  useEffect(() => {
    if (onElectricalSummaryChange) {
      onElectricalSummaryChange(getElectricalSummary());
    }
  }, [electricalRows]); // eslint-disable-line react-hooks/exhaustive-deps

  const buildElectricalPayload = () => {
    return {
      Reference_No: electricalRows[0]?.refNo || "",

      Common: {
        Dimension_Parameter: electricalCommon.dimensionParameter || "",
        Unit: electricalCommon.unit || "",
        Remarks: electricalCommon.remarks || "",
        Marking_On_Material: electricalCommon.markingOnMaterial || "",
        Visual_Inspection_Report: electricalCommon.visualInspection || "",
        Electrical_Inspection_Remark: "",
        Electrical_Parameter: "",
        Functional: "",
        Dimensions: "",
        Visual_Inspection: "",
        COC: electricalCommon.coc || "",
        Test_Reports: electricalCommon.testReports || "",
        Imported_Doc_Received: "",
        Malware_Free_Cert: "",
        FOD_Check: "",
        Counterfeit_Checked: "",
        MFG_Date: null,
        Exp_Date: null,
        Qty_Received: electricalCommon.qtyReceived || "",
        Qty_Inspected: getElectricalQtyInspected(),
        Qty_Accepted: getElectricalSummary().accepted,
        Qty_Rejected: getElectricalSummary().rejected,
        Inspection_Remarks: electricalCommon.inspectionRemarks || "",
      },

      Dimensions: electricalRows.map((r) => ({
        Report_Id: r.Dimension_Report_Id,
        Dimension_Name: r.Dimension_Name,
        Samples: r.observed
          .map((value, index) => {
            if (!value) return null;

            const num = parseFloat(value);
            const min = parseFloat(r.min);
            const max = parseFloat(r.max);

            const status =
              !isNaN(num) && num >= min && num <= max ? "Accepted" : "Rejected";

            return {
              Sample_No: index + 1,
              Value: num,
              Status: status,
            };
          })
          .filter((x) => x !== null),
      })),
    };
  };

  // ==========================================================
  // COMBINED SAVE HANDLER
  // ==========================================================

  const buildCombinedPayload = () => {
    const physicalPayload = buildPhysicalPayload();
    const electricalPayload = buildElectricalPayload();

    return {
      Physical: physicalPayload,
      Electrical: electricalPayload,
    };
  };

  const handleSave = async () => {
    try {
      const payload = buildCombinedPayload();
      console.log("Final Combined Payload:", payload);

      await axios.post(
        "http://192.168.0.149:8000/dimensionreport/samples",
        payload
      );

      alert("Electromechanical data saved successfully!");
    } catch (error) {
      console.error("Error saving data:", error);
      alert("Failed to save data.");
    }
  };

  // ==========================================================
  // RENDER
  // ==========================================================
  return (
    <Grid item xs={12}>
      <Divider sx={{ my: 1 }} />

      {/* ===================== PHYSICAL SECTION ===================== */}
      <Box p={2} sx={{ backgroundColor: "#fff", borderRadius: "12px", mb: 4 }}>
        <Typography
          variant="h6"
          align="center"
          sx={{
            fontWeight: "bold",
            mb: 2,
            fontSize: 16,
            color: "black",
            fontFamily: "Times New Roman",
          }}
        >
          MECHANICAL / PHYSICAL INSPECTION - DIMENSIONAL CHECK
        </Typography>

        {/* <Typography sx={{ mt: 2, fontWeight: "bold" }}>
          General Tolerance: ± {TOLERANCE}
        </Typography> */}

        <Box sx={{ display: "flex", justifyContent: "right", gap: 2, mt: 2 }}>
          <AddCircleIcon
            color="success"
            sx={{ cursor: "pointer" }}
            onClick={() => {
              const newRow = {
                slno: physicalRows.length + 1,
                instrument: "",
                basicDimension: "",
                min: "",
                max: "",
                observed: Array(sampleCount).fill(""),
                remarks: "",
              };
              const updated = [...physicalRows, newRow];
              setPhysicalRows(updated);
            }}
          />

          <DeleteIcon
            color="error"
            sx={{
              cursor: physicalRows.length === 1 ? "not-allowed" : "pointer",
              opacity: physicalRows.length === 1 ? 0.5 : 1,
            }}
            onClick={() => {
              if (physicalRows.length === 1) return;
              const updated = physicalRows.slice(0, -1);
              setPhysicalRows(updated);
            }}
          />

          <Button
            variant="contained"
            color="primary"
            startIcon={<VisibilityIcon />}
            sx={{
              width: "12rem",
              fontWeight: "bold",
              borderRadius: "8px",
              boxShadow: 2,
            }}
            onClick={() => setShowPhysicalResults((prev) => !prev)}
          >
            {showPhysicalResults ? "Hide Results" : "Show Results"}
          </Button>
        </Box>

        <TableContainer
          component={Paper}
          sx={{ border: "1px solid black", mt: 2, borderRadius: "12px" }}
        >
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  SL No
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Dimension Parameter
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Basic Value
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Min
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Max
                </TableCell>
                {Array.from({ length: sampleCount }, (_, i) => (
                  <TableCell
                    key={i}
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontWeight: "bold",
                    }}
                  >
                    {i + 1}
                  </TableCell>
                ))}
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Remarks
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {physicalRows.map((row, i) => (
                <TableRow key={i}>
                  <TableCell
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontFamily: "Times New Roman",
                    }}
                  >
                    {i + 1}
                  </TableCell>

                  <TableCell>
                    <TextField
                      variant="standard"
                      fullWidth
                      value={row.dimensionParameter}
                      onChange={(e) =>
                        handlePhysicalChange(
                          i,
                          "dimensionParameter",
                          e.target.value
                        )
                      }
                    />
                  </TableCell>

                  <TableCell
                    sx={{ border: "1px solid black", fontFamily: "Times New Roman" }}
                  >
                    <TextField
                      variant="standard"
                      fullWidth
                      value={row.basicDimension}
                      onChange={(e) =>
                        handlePhysicalChange(i, "basicDimension", e.target.value)
                      }
                    />
                  </TableCell>

                  <TableCell
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontFamily: "Times New Roman",
                    }}
                  >
                    {row.min}
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontFamily: "Times New Roman",
                    }}
                  >
                    {row.max}
                  </TableCell>

                  {row.observed.map((val, j) => (
                    <TableCell
                      key={j}
                      sx={{
                        border: "1px solid black",
                        backgroundColor: isRejectedValuePhysical(
                          val,
                          row.min,
                          row.max
                        )
                          ? "#ff9999"
                          : validatePhysicalSample(j)
                          ? "#ccffcc"
                          : "",
                      }}
                    >
                      <TextField
                        variant="standard"
                        fullWidth
                        value={val}
                        onChange={(e) =>
                          handlePhysicalChange(
                            i,
                            "observed",
                            e.target.value,
                            j
                          )
                        }
                      />
                    </TableCell>
                  ))}

                  <TableCell sx={{ border: "1px solid black" }}>
                    <TextField
                      variant="standard"
                      fullWidth
                      value={row.remarks}
                      onChange={(e) =>
                        handlePhysicalChange(i, "remarks", e.target.value)
                      }
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {showPhysicalResults && (
          <Box mt={4}>
            <Typography
              variant="h6"
              sx={{
                fontWeight: "bold",
                mb: 1,
                textAlign: "center",
                fontFamily: "Times New Roman",
                fontSize: 18,
              }}
            >
              PHYSICAL INSPECTION RESULTS
            </Typography>
            <TableContainer component={Paper} sx={{ border: "1px solid black" }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Sample
                    </TableCell>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Basic Dimension
                    </TableCell>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Observed Value
                    </TableCell>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Result
                    </TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {getPhysicalInspectionResults().map((res, idx) => (
                    <React.Fragment key={idx}>
                      {res.basicDimensions.map((dim, dIdx) => (
                        <TableRow key={`${idx}-${dIdx}`}>
                          {dIdx === 0 && (
                            <TableCell
                              rowSpan={res.basicDimensions.length}
                              sx={{
                                border: "1px solid black",
                                textAlign: "center",
                                verticalAlign: "middle",
                                fontWeight: "bold",
                              }}
                            >
                              {res.sample}
                            </TableCell>
                          )}

                          <TableCell
                            sx={{ border: "1px solid black", textAlign: "center" }}
                          >
                            {dim}
                          </TableCell>

                          <TableCell
                            sx={{ border: "1px solid black", textAlign: "center" }}
                          >
                            {res.observedValues[dIdx]}
                          </TableCell>

                          {dIdx === 0 && (
                            <TableCell
                              rowSpan={res.basicDimensions.length}
                              sx={{
                                border: "1px solid black",
                                textAlign: "center",
                                verticalAlign: "middle",
                                color:
                                  res.status === "Rejected" ? "red" : "green",
                                fontWeight: "bold",
                              }}
                            >
                              {res.status}
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                    </React.Fragment>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        )}
      </Box>

      {/* ===================== ELECTRICAL SECTION ===================== */}
      <Box p={2} sx={{ backgroundColor: "#fff", borderRadius: "12px", mb: 4 }}>
        <Typography
          variant="h6"
          align="center"
          sx={{
            fontWeight: "bold",
            mb: 2,
            fontFamily: "Times New Roman",
            fontSize: 18,
          }}
        >
          ELECTRICAL INSPECTION - MEASUREMENT CHECK
        </Typography>

        <Box sx={{ display: "flex", justifyContent: "right", gap: 2, mt: 2 }}>
          <AddCircleIcon
            color="success"
            sx={{ cursor: "pointer" }}
            onClick={() => {
              const newRow = {
                slno: electricalRows.length + 1,
                instrument: "",
                basicDimension: "",
                min: "",
                max: "",
                observed: Array(sampleCount).fill(""),
              };
              const updated = [...electricalRows, newRow];
              setElectricalRows(updated);
            }}
          />

          <DeleteIcon
            color="error"
            sx={{
              cursor: electricalRows.length === 1 ? "not-allowed" : "pointer",
              opacity: electricalRows.length === 1 ? 0.5 : 1,
            }}
            onClick={() => {
              if (electricalRows.length === 1) return;
              const updated = electricalRows.slice(0, -1);
              setElectricalRows(updated);
            }}
          />

          <Button
            variant="contained"
            color="primary"
            startIcon={<VisibilityIcon />}
            sx={{
              width: "12rem",
              fontWeight: "bold",
              borderRadius: "8px",
              boxShadow: 2,
            }}
            onClick={() => setShowElectricalResults((prev) => !prev)}
          >
            {showElectricalResults ? "Hide Results" : "Show Results"}
          </Button>
        </Box>

        <TableContainer
          component={Paper}
          sx={{ border: "1px solid black", mt: 2, borderRadius: "12px" }}
        >
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  SL No
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Basic Value
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Unit
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Min
                </TableCell>
                <TableCell
                  sx={{
                    border: "1px solid black",
                    textAlign: "center",
                    fontWeight: "bold",
                    fontFamily: "Times New Roman",
                  }}
                >
                  Max
                </TableCell>
                {Array.from({ length: sampleCount }, (_, i) => (
                  <TableCell
                    key={i}
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontWeight: "bold",
                    }}
                  >
                    {i + 1}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {electricalRows.map((row, i) => (
                <TableRow key={i}>
                  <TableCell
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontFamily: "Times New Roman",
                    }}
                  >
                    {i + 1}
                  </TableCell>

                  <TableCell
                    sx={{ border: "1px solid black", fontFamily: "Times New Roman" }}
                  >
                    <TextField
                      select
                      variant="standard"
                      fullWidth
                      value={row.basicDimension}
                      onChange={(e) =>
                        handleElectricalChange(
                          i,
                          "basicDimension",
                          e.target.value
                        )
                      }
                      SelectProps={{ native: true }}
                    >
                      <option value="">Select Dimension</option>
                      {electricalBasicDimensions.map((d, idx) => (
                        <option key={idx} value={d.dimension}>
                          {d.dimension}
                        </option>
                      ))}
                    </TextField>
                  </TableCell>

                  <TableCell
                    sx={{ border: "1px solid black", fontFamily: "Times New Roman" }}
                  >
                    <TextField
                      select
                      variant="standard"
                      fullWidth
                      value={selectedMeasurement}
                      onChange={handleMeasurementChange}
                      SelectProps={{ native: true }}
                    >
                      <option value="">Select Measurement</option>
                      {measurements.map((measurement) => (
                        <option
                          key={measurement.value}
                          value={measurement.value}
                        >
                          {measurement.label}
                        </option>
                      ))}
                    </TextField>
                  </TableCell>

                  <TableCell
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontFamily: "Times New Roman",
                    }}
                  >
                    {row.min}
                  </TableCell>
                  <TableCell
                    sx={{
                      border: "1px solid black",
                      textAlign: "center",
                      fontFamily: "Times New Roman",
                    }}
                  >
                    {row.max}
                  </TableCell>

                  {row.observed.map((val, j) => (
                    <TableCell
                      key={j}
                      sx={{
                        border: "1px solid black",
                        backgroundColor: isRejectedValueElectrical(
                          val,
                          row.min,
                          row.max
                        )
                          ? "#ff9999"
                          : validateElectricalSample(j)
                          ? "#ccffcc"
                          : "",
                      }}
                    >
                      <TextField
                        variant="standard"
                        fullWidth
                        value={val}
                        onChange={(e) =>
                          handleElectricalChange(
                            i,
                            "observed",
                            e.target.value,
                            j
                          )
                        }
                      />
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {showElectricalResults && (
          <Box mt={4}>
            <Typography
              variant="h6"
              sx={{
                fontWeight: "bold",
                mb: 1,
                textAlign: "center",
                fontFamily: "Times New Roman",
                fontSize: 18,
              }}
            >
              ELECTRICAL INSPECTION RESULTS
            </Typography>
            <TableContainer component={Paper} sx={{ border: "1px solid black" }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Sample
                    </TableCell>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Basic Dimension
                    </TableCell>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Observed Value
                    </TableCell>
                    <TableCell
                      sx={{ border: "1px solid black", textAlign: "center", fontWeight: "bold" }}
                    >
                      Result
                    </TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {getElectricalInspectionResults().map((res, idx) => (
                    <React.Fragment key={idx}>
                      {res.basicDimensions.map((dim, dIdx) => (
                        <TableRow key={`${idx}-${dIdx}`}>
                          {dIdx === 0 && (
                            <TableCell
                              rowSpan={res.basicDimensions.length}
                              sx={{
                                border: "1px solid black",
                                textAlign: "center",
                                verticalAlign: "middle",
                                fontWeight: "bold",
                              }}
                            >
                              {res.sample}
                            </TableCell>
                          )}

                          <TableCell
                            sx={{ border: "1px solid black", textAlign: "center" }}
                          >
                            {dim}
                          </TableCell>

                          <TableCell
                            sx={{ border: "1px solid black", textAlign: "center" }}
                          >
                            {res.observedValues[dIdx]}
                          </TableCell>

                          {dIdx === 0 && (
                            <TableCell
                              rowSpan={res.basicDimensions.length}
                              sx={{
                                border: "1px solid black",
                                textAlign: "center",
                                verticalAlign: "middle",
                                color:
                                  res.status === "Rejected" ? "red" : "green",
                                fontWeight: "bold",
                              }}
                            >
                              {res.status}
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                    </React.Fragment>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        )}
      </Box>

      {/* ===================== INSTRUMENTS USED ===================== */}
      <Box p={2} sx={{ backgroundColor: "#fff", borderRadius: "12px", mb: 4 }}>
        <Typography
          variant="h6"
          align="center"
          sx={{
            fontWeight: "bold",
            mb: 2,
            fontFamily: "Times New Roman",
            fontSize: 18,
          }}
        >
          INSTRUMENTS USED
        </Typography>
        <InstrumentList />
      </Box>

      {/* ===================== SAVE BUTTON ===================== */}
      <Box sx={{ display: "flex", justifyContent: "center", mb: 2 }}>
        <Button
          variant="contained"
          startIcon={<SaveIcon />}
          onClick={handleSave}
          sx={{
            width: "10rem",
            background: "linear-gradient(135deg, #e3f2fd, #bbdefb)",
            color: "#0d47a1",
            fontWeight: "bold",
            borderRadius: "8px",
            boxShadow: 2,
            "&:hover": {
              background: "linear-gradient(135deg, #bbdefb, #90caf9)",
              boxShadow: 4,
            },
          }}
        >
          Save
        </Button>
      </Box>
    </Grid>
  );
}

export default ElectromechanicalForm;
