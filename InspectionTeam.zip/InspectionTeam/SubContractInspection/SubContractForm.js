import React, { useEffect, useState } from "react";
import axios from "axios";
import CancelIcon from "@mui/icons-material/Cancel";
import TaskIcon from "@mui/icons-material/Task";
import {
  Box,
  Button,
  TableContainer,
  Table,
  TableBody,
  TableCell,
  TableRow,
  TextField,
  Typography,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Stack,
} from "@mui/material";

/* ============================================================
   SUB CONTRACTOR INSPECTION REPORT FORM
   ============================================================ */

function SubContractForm({ selectedRow, onClose }) {
  /* ------------------------------------------------------------
     FORM STATE
     ------------------------------------------------------------ */
  const [formData, setFormData] = useState({
    controlNo: "",
    sample: "",
    date: "",
    partNo: "",
    drgIssueLevel: "",
    projectOrder: "",
    description: "",
    sanNo: "",
    poNo: "",
    vendor: "",
    quantityReceived: "",
    referenceNo: "",
    versionNo: "",
    rawMaterial: "",
    finish: "",
  });

  const [checks, setChecks] = useState({
    vendorDim: "",
    visual: "",
    rawMat: "",
    rawMatReport: "",
    finishTestReport: "",
  });

  /* ------------------------------------------------------------
     POPULATE FORM WHEN EDITING SELECTED ROW
     ------------------------------------------------------------ */
  useEffect(() => {
    if (!selectedRow) return;

    const row = selectedRow;

    setFormData({
      controlNo: row.Control_No || "",
      sample: row.Sample || "",
      date: row.Date?.split("T")[0] || "",
      partNo: row.Part_No || "",
      drgIssueLevel: row.Drg_Issue_Level || "",
      projectOrder: row.Sale_Order || "",
      description: row.Description || "",
      sanNo: row.SAN_NO || "",
      poNo: row.PO_NO || "",
      vendor: row.Vendor_Name || "",
      quantityReceived: row.Quantity || "",
      referenceNo: row.Reference_No || "",
      versionNo: row.Version_No || "",
      rawMaterial: row.Raw_Material || "",
      finish: row.Finish || "",
    });

    setChecks({
      vendorDim: row.Vendor_Dim || "",
      visual: row.Visual || "",
      rawMat: row.Raw_Mat || "",
      rawMatReport: row.Raw_Mat_Report || "",
      finishTestReport: row.Finish_Test_Report || "",
    });
  }, [selectedRow]);

  /* ------------------------------------------------------------
     HANDLERS
     ------------------------------------------------------------ */
  const handleInputChange = (field, value) =>
    setFormData((prev) => ({ ...prev, [field]: value }));

  const handleCheck = (name, value) =>
    setChecks((prev) => ({ ...prev, [name]: value }));

  const renderCheckboxGroup = (name, options) => (
    <FormGroup row sx={{ justifyContent: "space-evenly" }}>
      {options.map((label) => (
        <FormControlLabel
          key={label}
          control={
            <Checkbox
              checked={checks[name] === label}
              onChange={() => handleCheck(name, label)}
            />
          }
          label={label}
        />
      ))}
    </FormGroup>
  );

  /* ------------------------------------------------------------
     SAVE DATA TO API
     ------------------------------------------------------------ */
  const handleSave = () => {
    const payload = {
      Control_No: parseInt(formData.controlNo) || 0,
      Description: formData.description,
      Drg_Issue_Level: parseInt(formData.drgIssueLevel) || 0,
      PO_NO: formData.poNo,
      Part_No: formData.partNo,
      Quantity: formData.quantityReceived,
      Raw_Material_Supplied: checks.rawMat,
      Raw_Material_Test_Report: checks.rawMatReport,
      SAN_NO: parseInt(formData.sanNo) || 0,
      Sale_Order: formData.projectOrder,
      Sample: formData.sample,
      Vendor_Dimension_Report: checks.vendorDim,
      Vendor_Name: formData.vendor,
      Visual_Inspection: checks.visual,
      Date: formData.date,
      Version_No: formData.versionNo,
      Raw_Material: formData.rawMaterial,
      Finish: formData.finish,
      Finish_Test_Report: checks.finishTestReport,
    };

    const params = {
      Ref_No: formData.referenceNo || `REF-${Date.now()}`,
    };

    axios
      .put("http://192.168.0.149:8000/subcontractinspectionreport", payload, {
        params,
      })
      .then(() => alert("Saved successfully!"))
      .catch(() => alert("Save failed, please try again."));
  };

  /* ============================================================
     UI RENDER
     ============================================================ */

  return (
    <Box p={2}>
      <Typography
        variant="h6"
        align="center"
        sx={{ fontWeight: "bold", mb: 1, color: "#0d47a1" }}
      >
        SUB CONTRACTOR INSPECTION - MCE DIVISION
      </Typography>

      <Typography
        variant="h6"
        align="center"
        sx={{ fontWeight: "bold", mb: 2, color: "#0d47a1" }}
      >
        INSPECTION REPORT
      </Typography>

      {/* ============================================================
          FORM TABLE
          ============================================================ */}
      {/* ===================== TABLE 1 — TEXT FIELDS ===================== */}
<TableContainer sx={{ border: "1px solid black", mb: 3 }}>
  <Table size="small">
    <TableBody>

      {/* ROW 1 */}
      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>CONTROL NO:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.controlNo}
            onChange={(e) => handleInputChange("controlNo", e.target.value)}
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>SAMPLE:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.sample}
            onChange={(e) => handleInputChange("sample", e.target.value)}
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>DATE:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            type="date"
            value={formData.date}
            onChange={(e) => handleInputChange("date", e.target.value)}
          />
        </TableCell>
      </TableRow>

      {/* ROW 2 */}
      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>PART NO:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.partNo}
            onChange={(e) => handleInputChange("partNo", e.target.value)}
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>DRG ISSUE LEVEL:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.drgIssueLevel}
            onChange={(e) =>
              handleInputChange("drgIssueLevel", e.target.value)
            }
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>PROJECT / SALE ORDER:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.projectOrder}
            onChange={(e) => handleInputChange("projectOrder", e.target.value)}
          />
        </TableCell>
      </TableRow>

      {/* ROW 3 */}
      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>DESCRIPTION:</TableCell>
        <TableCell sx={{ border: "1px solid black" }} colSpan={5}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.description}
            onChange={(e) => handleInputChange("description", e.target.value)}
          />
        </TableCell>
      </TableRow>

      {/* ROW 4 */}
      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>SAN NO:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.sanNo}
            onChange={(e) => handleInputChange("sanNo", e.target.value)}
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>PO NO:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.poNo}
            onChange={(e) => handleInputChange("poNo", e.target.value)}
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>VENDOR:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.vendor}
            onChange={(e) => handleInputChange("vendor", e.target.value)}
          />
        </TableCell>
      </TableRow>

      {/* ROW 5 */}
      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>VERSION NO:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.versionNo}
            onChange={(e) => handleInputChange("versionNo", e.target.value)}
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>RAW MATERIAL:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.rawMaterial}
            onChange={(e) =>
              handleInputChange("rawMaterial", e.target.value)
            }
          />
        </TableCell>

        <TableCell sx={{ border: "1px solid black" }}>FINISH:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          <TextField
            variant="standard"
            fullWidth
            value={formData.finish}
            onChange={(e) => handleInputChange("finish", e.target.value)}
          />
        </TableCell>
      </TableRow>

    </TableBody>
  </Table>
</TableContainer>



{/* ===================== TABLE 2 — CHECKBOXES ONLY ===================== */}
<TableContainer sx={{ border: "1px solid black" }}>
  <Table size="small">
    <TableBody>

      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>VENDOR DIMENSION REPORT:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          {renderCheckboxGroup("vendorDim", ["Received", "Not Received"])}
        </TableCell>
      </TableRow>

      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>VISUAL INSPECTION 100%:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          {renderCheckboxGroup("visual", ["OK", "Not OK"])}
        </TableCell>
      </TableRow>

      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>RAW MATERIAL SUPPLIED:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          {renderCheckboxGroup("rawMat", ["BE", "Vendor"])}
        </TableCell>
      </TableRow>

      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>RAW MATERIAL TEST REPORT:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          {renderCheckboxGroup("rawMatReport", ["Received", "Not Received"])}
        </TableCell>
      </TableRow>

      <TableRow>
        <TableCell sx={{ border: "1px solid black" }}>FINISH TEST REPORT:</TableCell>
        <TableCell sx={{ border: "1px solid black" }}>
          {renderCheckboxGroup("finishTestReport", ["Received", "Not Received"])}
        </TableCell>
      </TableRow>

    </TableBody>
  </Table>
</TableContainer>


      {/* ============================================================
          ACTION BUTTONS
          ============================================================ */}
      <Stack direction="row" justifyContent="center" sx={{ my: 2, gap: 4 }}>
        <Button onClick={handleSave} sx={{ color: "green" }}>
          <TaskIcon /> SAVE
        </Button>

        <Button onClick={onClose} sx={{ color: "red" }}>
          <CancelIcon /> CLOSE
        </Button>
      </Stack>
    </Box>
  );
}

export default SubContractForm;
