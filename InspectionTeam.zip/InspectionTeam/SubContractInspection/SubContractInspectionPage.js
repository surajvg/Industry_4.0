// REFACTORED: Clean structure, removed unwanted comments, kept meaningful section headers.
// NOTE: All functionality, JSX, logic, and structure remain EXACTLY the same.

import React, { useEffect, useState } from "react";
import {
    Box,
    Button,
    Card,
    CardContent,
    Checkbox,
    Divider,
    Grid,
    Paper,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    TextField,
    Typography,
    MenuItem,
} from "@mui/material";
import { QRCodeSVG } from "qrcode.react";
import axios from "axios";
import DimensionalForm from './DimensionalForm';
import SubContractForm from "./SubContractForm";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import CancelIcon from "@mui/icons-material/Cancel";
import SummarizeIcon from "@mui/icons-material/Summarize";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import { QrCode2 } from "@mui/icons-material";
import { TaskAlt } from "@mui/icons-material";
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import Tooltip from "@mui/material/Tooltip";
import PauseCircleOutlineIcon from "@mui/icons-material/PauseCircleOutline";

import PhysicalForm from "../SubContractInspection/PhysicalForm";
import ElectricalForm from "../SubContractInspection/ElectricalForm";

export default function SubContractInspection() {
    // --------------------------------------------
    // STATE MANAGEMENT
    // --------------------------------------------
    const [filter, setFilter] = useState("pending");
    const [tab, setTab] = useState("pending");
    const [pendingData, setPendingData] = useState([]);
    const [showExtra, setShowExtra] = useState(false);
    const [inspectionSummary, setInspectionSummary] = useState({ accepted: 0, rejected: 0 });
    const [electricalSummary, setElectricalSummary] = useState({ accepted: 0, rejected: 0 });
    const [referenceno, setReferenceNo] = useState([]);

    const [selectedId, setSelectedId] = useState(null);

    const [form, setForm] = useState({
        partNumber: "",
        mpn: "",
        batchNo: "",
        poNo: "",
        vendor: "",
        totalQty: 0,
        samplingPercent: 10,
        sampleQty: 0,
        acceptedInSample: "",
        rejectedInSample: "",
        inspectedBy: "",
        date: "",
        signature: "",
    });

    const [report, setReport] = useState({
        controlNo: "",
        remarks: "",
    });

    const [qrOpen, setQrOpen] = useState(false);
    const [qrType, setQrType] = useState(null);
    const [qrPayload, setQrPayload] = useState("");
    const [hoveredRow, setHoveredRow] = useState(null);
    const [dimensiondata, setDimensionData] = useState(null);
    const [activeCard, setActiveCard] = useState("pending");
    const [percentError, setPercentError] = useState("");
    const [indenterIntervention, setIndenterIntervention] = useState(false);
    const [processOnHold, setProcessOnHold] = useState(false);
    const [isCardOpen, setIsCardOpen] = useState(true);

    // --------------------------------------------
    // FETCH PENDING GR LIST
    // --------------------------------------------
    useEffect(() => {
        const fetchData = async () => {
            try {
                const res = await axios.get("http://192.168.0.149:8000/generateddetails");
                const formattedData = res.data.map((item) => ({
                    slno: item.SL_No,
                    partNumber: item.BEL_Part_Number,
                    mpn: item.MPN,
                    batchNo: item.Batch_Lot_No,
                    dateCode: item.DateCode,
                    quantity: item.Quantity,
                    poNo: item.BEL_PO_No,
                    vendor: item.Vendor_Name,
                    oemMake: item.OEM_Make,
                    manufacture: item.Manufacturing_Place,
                    grNo: item.GR_No || "",
                    grDate: item.GR_Date ? item.GR_Date.split("T")[0] : "",
                    receiptNo: item.Reference_No || "",
                }));
                setPendingData(formattedData);
            } catch {
                const dummyData = [
                    {
                        SL_No: 1,
                        GR_No: "GR2025-001",
                        GR_Date: "2025-01-15T10:23:00.000Z",
                        BEL_Part_Number: "423458754153",
                        MPN: "MPN-AX45",
                        Batch_Lot_No: "BATCH-789",
                        DateCode: "2024-12",
                        Quantity: 150,
                        BEL_PO_No: "PO-56789",
                        Vendor_Name: "ABC Electronics Pvt Ltd",
                        OEM_Make: "Siemens",
                        Manufacturing_Place: "Germany",
                        Reference_No: "RCPT-001"
                    },
                    {
                        SL_No: 2,
                        GR_No: "GR2025-002",
                        GR_Date: "2025-01-20T09:10:00.000Z",
                        BEL_Part_Number: "245875415332",
                        MPN: "MPN-ZX90",
                        Batch_Lot_No: "BATCH-456",
                        DateCode: "2025-01",
                        Quantity: 300,
                        BEL_PO_No: "PO-99887",
                        Vendor_Name: "Global Tech Supplies",
                        OEM_Make: "Honeywell",
                        Manufacturing_Place: "USA",
                        Reference_No: "RCPT-002"
                    },
                    {
                        SL_No: 3,
                        GR_No: "GR2025-003",
                        GR_Date: "2025-01-22T14:45:00.000Z",
                        BEL_Part_Number: "165654678900",
                        MPN: "MPN-QT12",
                        Batch_Lot_No: "BATCH-123",
                        DateCode: "2024-10",
                        Quantity: 75,
                        BEL_PO_No: "PO-11223",
                        Vendor_Name: "Precision Components Ltd",
                        OEM_Make: "Bosch",
                        Manufacturing_Place: "India",
                        Reference_No: "RCPT-003"
                    }
                ];

                const formattedDummy = dummyData.map((item) => ({
                    slno: item.SL_No,
                    grNo: item.GR_No || "",
                    grDate: item.GR_Date ? item.GR_Date.split("T")[0] : "",
                    partNumber: item.BEL_Part_Number,
                    mpn: item.MPN,
                    batchNo: item.Batch_Lot_No,
                    dateCode: item.DateCode,
                    quantity: item.Quantity,
                    poNo: item.BEL_PO_No,
                    vendor: item.Vendor_Name,
                    oemMake: item.OEM_Make,
                    manufacture: item.Manufacturing_Place,
                    receiptNo: item.Reference_No || "",
                }));

                setPendingData(formattedDummy);
            }
        };
        fetchData();
    }, []);

    // --------------------------------------------
    // AUTOFILL FORM WHEN SELECTED ID CHANGES
    // --------------------------------------------
    useEffect(() => {
        if (selectedId == null) {
            setForm((f) => ({
                ...f,
                partNumber: "",
                mpn: "",
                batchNo: "",
                poNo: "",
                vendor: "",
                totalQty: 0,
                sampleQty: 0,
                samplingPercent: 10,
                acceptedInSample: "",
                rejectedInSample: "",
            }));
            return;
        }

        const row = pendingData.find((r) => r.slno === selectedId);
        if (!row) return;

        setForm((f) => ({
            ...f,
            partNumber: row.partNumber,
            mpn: row.mpn,
            batchNo: row.batchNo,
            poNo: row.poNo,
            totalQty: row.quantity,
            vendor: row.vendor,
            samplingPercent: 10,
            sampleQty: Math.round((row.quantity * 10) / 100),
            acceptedInSample: "",
            rejectedInSample: "",
        }));
    }, [selectedId]);

    // --------------------------------------------
    // RECALC SAMPLE QTY WHEN SAMPLING PERCENT OR TOTAL QTY CHANGES
    // --------------------------------------------
    useEffect(() => {
        const p = Number(form.samplingPercent || 0);
        const total = Number(form.totalQty || 0);
        if (isNaN(p) || p < 0) return;
        const s = Math.round((total * Math.max(0, Math.min(100, p))) / 100);
        setForm((f) => ({ ...f, sampleQty: s }));
    }, [form.samplingPercent, form.totalQty]);

    // --------------------------------------------
    // RECALC REJECTED WHEN ACCEPTED IN SAMPLE CHANGES
    // --------------------------------------------
    useEffect(() => {
        const acc = form.acceptedInSample === "" ? null : Number(form.acceptedInSample);
        if (acc === null || isNaN(acc)) {
            setForm((f) => ({ ...f, rejectedInSample: "" }));
            return;
        }
        const rej = Number(form.sampleQty) - acc;
        setForm((f) => ({ ...f, rejectedInSample: String(rej >= 0 ? rej : 0) }));
    }, [form.acceptedInSample, form.sampleQty]);

    // --------------------------------------------
    // HANDLE PART NUMBER CLICK (FETCH REPORTS)
    // --------------------------------------------
    const handlePartNumberClick = (row) => {
        const baseURL = "http://192.168.0.149:8000/subcontractinspectionreport";

        axios.get(baseURL, {
            params: {
                Ref_No: row.receiptNo
            }
        })
            .then((res) => {
                setHoveredRow(res.data);
                setReferenceNo(res.data.Reference_No);
                setIsCardOpen(true);
            })
            .catch((err) => console.error("API error:", err));

        const baseURL2 = "http://192.168.0.149:8000/dimensionreport";

        axios.get(baseURL2, {
            params: {
                Ref_No: row.receiptNo
            }
        })
            .then((res) => {
                setDimensionData(res.data);
            })
            .catch((err) => console.error("API error:", err));
    };

    // --------------------------------------------
    // QR PAYLOAD BUILDER
    // --------------------------------------------
    function buildQrPayload(type) {
        const payload = {
            result: type === "accept" ? "ACCEPTED" : "REJECTED",
            partNumber: form.partNumber,
            mpn: form.mpn,
            batchNo: form.batchNo,
            poNo: form.poNo,
            totalQuantity: form.totalQty,
            samplingPercent: form.samplingPercent,
            sampleQty: form.sampleQty,
            acceptedInSample: form.acceptedInSample || (type === "accept" && form.totalQty) || 0,
            rejectedInSample: form.rejectedInSample || (type === "reject" && form.totalQty) || 0,
            inspectedBy: form.inspectedBy,
            date: form.date,
            signature: form.signature,
            controlNo: report.controlNo,
            vendor: report.vendor,
            remarks: report.remarks,
        };

        return Object.entries(payload)
            .map(([k, v]) => `${k}: ${v}`)
            .join("\n");
    }

    // --------------------------------------------
    // VALIDATION BEFORE OPENING QR
    // --------------------------------------------
    function validateBeforeQr() {
    // Must select a row
    if (!form.partNumber) return "Select a row from the GR list first.";

    // Must have quantity
    if (form.totalQty <= 0) return "Invalid total quantity.";

    // Inspected By check
    if (!form.inspectedBy || form.inspectedBy.trim() === "")
        return "Enter 'Inspected By' (Staff ID).";

    // Date check
    if (!form.date) return "Select Inspection Date.";

    // Compute inspection totals
    const totalInspected =
        Number(inspectionSummary.accepted || 0) +
        Number(inspectionSummary.rejected || 0) +
        Number(electricalSummary.accepted || 0) +
        Number(electricalSummary.rejected || 0);

    // Ensure Physical/Electrical inspection is done
    if (totalInspected <= 0)
        return "Inspection not completed. Perform physical/electrical inspection first.";

    // If process is ON HOLD — block QR generation
    if (processOnHold)
        return "Process is on hold. Resume before generating QR.";

    return null; // Passed all checks
}


    function handleOpenQr(type) {
        const err = validateBeforeQr();
        if (err) {
            alert(err);
            return;
        }
        setQrType(type);
        const payload = buildQrPayload(type);
        setQrPayload(payload);
        setQrOpen(true);
    }

    function handleCloseQr() {
        setQrOpen(false);
        setQrPayload("");
        setQrType(null);
    }

    // --------------------------------------------
    // STYLES
    // --------------------------------------------
    const cardStyle = (active, from, to) => ({
        background: active ? `linear-gradient(90deg, ${from}, ${to})` : "#f5f7fa",
        color: active ? "white" : "#222",
        cursor: "pointer",
        boxShadow: active ? "0 8px 20px rgba(16,24,40,0.12)" : "0 2px 8px rgba(16,24,40,0.06)",
        borderRadius: 1,
        transition: "all 0.18s ease",
    });

    // --------------------------------------------
    // RENDER
    // --------------------------------------------
    return (
        <Box sx={{ p: 1, minHeight: "100vh" }}>
            <Card sx={{ maxWidth: 3000, mx: "auto", borderRadius: 3, color: "#bf1212" }}>
                <CardContent>
                    <Typography id="title" value="subcontract" variant="h4" align="center" sx={{ fontWeight: 800, mb: 5, fontFamily: 'Roboto' }}>
                        SUB CONTRACT INSPECTION
                    </Typography>

                    <Grid container spacing={2} justifyContent="center" sx={{ mb: 3 }}>
                        <Grid item>
                            <Card
                                onClick={() => setTab("pending")}
                                sx={{
                                    width: 200,
                                    p: 2,
                                    cursor: "pointer",
                                    borderRadius: 3,
                                    textAlign: "center",
                                    boxShadow: tab === "pending"
                                        ? "0 4px 20px rgba(25,118,210,0.4)"
                                        : "0 2px 8px rgba(0,0,0,0.15)",
                                    background: tab === "pending"
                                        ? "linear-gradient(135deg, #1976d2, #42a5f5)"
                                        : "#e3f2fd",
                                    color: tab === "pending" ? "white" : "black",
                                    transition: "0.25s",
                                    "&:hover": {
                                        transform: "scale(1.05)",
                                    },
                                }}
                            >
                                <PendingActionsIcon sx={{ fontSize: 40 }} />
                                <Typography variant="h6" fontWeight={700}>Pending GR List</Typography>
                            </Card>
                        </Grid>

                        <Grid item>
                            <Card
                                onClick={() => setTab("accepted")}
                                sx={{
                                    width: 200,
                                    p: 2,
                                    cursor: "pointer",
                                    borderRadius: 3,
                                    textAlign: "center",
                                    boxShadow: tab === "accepted"
                                        ? "0 4px 20px rgba(46,125,50,0.4)"
                                        : "0 2px 8px rgba(0,0,0,0.15)",
                                    background: tab === "accepted"
                                        ? "linear-gradient(135deg, #2e7d32, #66bb6a)"
                                        : "#e8f5e9",
                                    color: tab === "accepted" ? "white" : "black",
                                    transition: "0.25s",
                                    "&:hover": {
                                        transform: "scale(1.05)",
                                    },
                                }}
                            >
                                <CheckCircleIcon sx={{ fontSize: 40 }} />
                                <Typography variant="h6" fontSize={19} fontWeight={700}>Accepted GR List</Typography>
                            </Card>
                        </Grid>

                        <Grid item>
                            <Card
                                onClick={() => setTab("rejected")}
                                sx={{
                                    width: 200,
                                    p: 2,
                                    cursor: "pointer",
                                    borderRadius: 3,
                                    textAlign: "center",
                                    boxShadow: tab === "rejected"
                                        ? "0 4px 20px rgba(211,47,47,0.4)"
                                        : "0 2px 8px rgba(0,0,0,0.15)",
                                    background: tab === "rejected"
                                        ? "linear-gradient(135deg, #d32f2f, #ef5350)"
                                        : "#ffebee",
                                    color: tab === "rejected" ? "white" : "black",
                                    transition: "0.25s",
                                    "&:hover": {
                                        transform: "scale(1.05)",
                                    },
                                }}
                            >
                                <CancelIcon sx={{ fontSize: 40 }} />
                                <Typography variant="h6" fontWeight={700}>Rejected GR List</Typography>
                            </Card>
                        </Grid>

                        <Grid item>
                            <Card
                                onClick={() => setTab("total")}
                                sx={{
                                    width: 200,
                                    p: 2,
                                    cursor: "pointer",
                                    borderRadius: 3,
                                    textAlign: "center",
                                    boxShadow: tab === "total"
                                        ? "0 4px 20px rgba(25,118,210,0.4)"
                                        : "0 2px 8px rgba(0,0,0,0.15)",
                                    background: tab === "total"
                                        ? "linear-gradient(135deg, #1565c0, #64b5f6)"
                                        : "#e3f2fd",
                                    color: tab === "total" ? "white" : "black",
                                    transition: "0.25s",
                                    "&:hover": {
                                        transform: "scale(1.05)",
                                    },
                                }}
                            >
                                <SummarizeIcon sx={{ fontSize: 40 }} />
                                <Typography variant="h6" fontWeight={700}>Total</Typography>
                            </Card>
                        </Grid>
                    </Grid>

                    <Box mt={4}>
                        {tab === "pending" && (
                            <>
                                <Grid container spacing={2}>
                                    <Grid item xs={12} md={12}>
                                        <Paper
                                            sx={{
                                                p: 2,
                                                mb: 2,
                                                backgroundColor: "#e3f2fd",
                                                borderRadius: "12px",
                                                boxShadow: "0px 4px 20px rgba(0,0,0,0.12)",
                                                border: "1px solid #bbdefb",
                                                transition: "0.3s",
                                                "&:hover": {
                                                    boxShadow: "0px 8px 28px rgba(0,0,0,0.18)",
                                                }
                                            }}
                                        >
                                            <Typography
                                                variant="h5"
                                                align="center"
                                                sx={{
                                                    mb: 2,
                                                    fontWeight: "bold",
                                                    fontFamily: "Times New Roman",
                                                    color: "black",
                                                    textShadow: "0px 1px 2px rgba(0,0,0,0.2)",
                                                }}
                                            >
                                                PENDING GR LIST FOR INSPECTION
                                            </Typography>

                                            <Table size="small">
                                                <TableHead>
                                                    <TableRow>
                                                        {[
                                                            "Sl No",
                                                            "BEL Part Number",
                                                            "MPN",
                                                            "Batch No",
                                                            "Date Code",
                                                            "Quantity",
                                                            "BEL PO No",
                                                            "Vendor",
                                                            "OEM Make",
                                                            "Manufacture",
                                                            "GR No",
                                                            "GR Date",
                                                            "Reference No"
                                                        ].map((h) => (
                                                            <TableCell
                                                                key={h}
                                                                sx={{
                                                                    fontWeight: 700,
                                                                    color: "white",
                                                                    backgroundColor: "#1565c0",
                                                                    fontFamily: "Times New Roman",
                                                                    borderRight: "1px solid #bbdefb",
                                                                    "&:last-child": { borderRight: "none" },
                                                                }}
                                                            >
                                                                {h}
                                                            </TableCell>
                                                        ))}
                                                    </TableRow>
                                                </TableHead>

                                                <TableBody>
                                                    {pendingData.map((row, i) => (
                                                        <TableRow
                                                            key={i}
                                                            hover
                                                            onClick={() => setSelectedId(row.slno)}
                                                            sx={{
                                                                backgroundColor:
                                                                    selectedId === row.slno ? "#c8e6c9" : "white",
                                                                cursor: "pointer",
                                                                fontFamily: "Times New Roman",
                                                                transition: "0.2s ease",
                                                                "&:hover": {
                                                                    backgroundColor:
                                                                        selectedId === row.slno
                                                                            ? "#aedfae"
                                                                            : "#f1f8ff",
                                                                    transform: "scale(1.01)",
                                                                },
                                                            }}
                                                        >
                                                            <TableCell>{row.slno}</TableCell>

                                                            <TableCell
                                                                style={{
                                                                    color: "#0d47a1",
                                                                    fontWeight: 700,
                                                                    textDecoration: "underline",
                                                                    cursor: "pointer",
                                                                }}
                                                                onClick={() => handlePartNumberClick(row)}
                                                            >
                                                                {row.partNumber}
                                                            </TableCell>

                                                            <TableCell>{row.grNo}</TableCell>
                                                            <TableCell>{row.grDate}</TableCell>
                                                            <TableCell>{row.mpn}</TableCell>
                                                            <TableCell>{row.batchNo}</TableCell>
                                                            <TableCell>{row.dateCode}</TableCell>
                                                            <TableCell>{row.quantity}</TableCell>
                                                            <TableCell>{row.poNo}</TableCell>
                                                            <TableCell>{row.vendor}</TableCell>
                                                            <TableCell>{row.oemMake}</TableCell>
                                                            <TableCell>{row.manufacture}</TableCell>
                                                            <TableCell>{row.receiptNo}</TableCell>
                                                        </TableRow>
                                                    ))}
                                                </TableBody>
                                            </Table>
                                        </Paper>

                                        {isCardOpen && (
                                            <SubContractForm
                                                selectedRow={hoveredRow}
                                                onClose={() => setIsCardOpen(false)}
                                            />
                                        )}
                                    </Grid>

                                    <Grid item xs={12} md={12}>
                                        <Paper sx={{ p: 2, mb: 2, background: "#e3f2fd" }}>
                                            <Typography variant="h6" sx={{ mb: 1, fontWeight: 'bold', color: 'black', fontFamily: 'Times New Roman' }}>
                                                SELECTED ITEM IMPORTANT DETAILS
                                            </Typography>

                                            <Grid container spacing={1}>
                                                <Grid container spacing={2} sx={{ width: "100%", mx: "auto" }}>
                                                    <Grid item xs={12} container spacing={2}>
                                                        <Grid item xs={3}>
                                                            <Box
                                                                sx={{
                                                                    p: 2,
                                                                    borderRadius: 2,
                                                                    background: "white",
                                                                    boxShadow: "0px 3px 12px rgba(0,0,0,0.12)",
                                                                    border: "1px solid #bbdefb",
                                                                    transition: "0.3s",
                                                                    "&:hover": {
                                                                        transform: "scale(1.03)",
                                                                        boxShadow: "0px 6px 20px rgba(0,0,0,0.2)",
                                                                    },
                                                                }}
                                                            >
                                                                <Typography
                                                                    variant="caption"
                                                                    sx={{
                                                                        fontSize: 16,
                                                                        fontWeight: 700,
                                                                        color: "#1565c0",
                                                                        fontFamily: "Times New Roman",
                                                                    }}
                                                                >
                                                                    Part No
                                                                </Typography>
                                                                <Box sx={{ mt: 1 }}>
                                                                    <Typography sx={{ fontWeight: 700 }}>
                                                                        {form.partNumber || "-"}
                                                                    </Typography>
                                                                </Box>
                                                            </Box>
                                                        </Grid>

                                                        <Grid item xs={3}>
                                                            <Box
                                                                sx={{
                                                                    p: 2,
                                                                    borderRadius: 2,
                                                                    background: "white",
                                                                    boxShadow: "0px 3px 12px rgba(0,0,0,0.12)",
                                                                    border: "1px solid #bbdefb",
                                                                    transition: "0.3s",
                                                                    "&:hover": {
                                                                        transform: "scale(1.03)",
                                                                        boxShadow: "0px 6px 20px rgba(0,0,0,0.2)",
                                                                    },
                                                                }}
                                                            >
                                                                <Typography
                                                                    variant="caption"
                                                                    sx={{
                                                                        fontSize: 16,
                                                                        fontWeight: 700,
                                                                        color: "#1565c0",
                                                                        fontFamily: "Times New Roman",
                                                                    }}
                                                                >
                                                                    MPN
                                                                </Typography>
                                                                <Box sx={{ mt: 1 }}>
                                                                    <Typography sx={{ fontWeight: 700 }}>
                                                                        {form.mpn || "-"}
                                                                    </Typography>
                                                                </Box>
                                                            </Box>
                                                        </Grid>

                                                        <Grid item xs={3}>
                                                            <Box
                                                                sx={{
                                                                    p: 2,
                                                                    borderRadius: 2,
                                                                    background: "white",
                                                                    boxShadow: "0px 3px 12px rgba(0,0,0,0.12)",
                                                                    border: "1px solid #bbdefb",
                                                                    transition: "0.3s",
                                                                    "&:hover": {
                                                                        transform: "scale(1.03)",
                                                                        boxShadow: "0px 6px 20px rgba(0,0,0,0.2)",
                                                                    },
                                                                }}
                                                            >
                                                                <Typography
                                                                    variant="caption"
                                                                    sx={{
                                                                        fontSize: 16,
                                                                        fontWeight: 800,
                                                                        color: "#1565c0",
                                                                        fontFamily: "Times New Roman",
                                                                    }}
                                                                >
                                                                    Batch No
                                                                </Typography>
                                                                <Box sx={{ mt: 1 }}>
                                                                    <Typography sx={{ fontWeight: 700 }}>
                                                                        {form.batchNo || "-"}
                                                                    </Typography>
                                                                </Box>
                                                            </Box>
                                                        </Grid>

                                                        <Grid item xs={3}>
                                                            <Box
                                                                sx={{
                                                                    p: 2,
                                                                    borderRadius: 2,
                                                                    background: "white",
                                                                    boxShadow: "0px 3px 12px rgba(0,0,0,0.12)",
                                                                    border: "1px solid #c8e6c9",
                                                                    transition: "0.3s",
                                                                    "&:hover": {
                                                                        transform: "scale(1.03)",
                                                                        boxShadow: "0px 6px 20px rgba(0,0,0,0.2)",
                                                                    },
                                                                }}
                                                            >
                                                                <Typography
                                                                    variant="caption"
                                                                    sx={{
                                                                        fontSize: 16,
                                                                        fontWeight: 700,
                                                                        color: "#2e7d32",
                                                                        fontFamily: "Times New Roman",
                                                                    }}
                                                                >
                                                                    Total Qty
                                                                </Typography>
                                                                <Box sx={{ mt: 1 }}>
                                                                    <Typography sx={{ fontWeight: 800, color: "green" }}>
                                                                        {form.totalQty}
                                                                    </Typography>
                                                                </Box>
                                                            </Box>
                                                        </Grid>
                                                    </Grid>
                                                </Grid>

                                                <Grid item xs={12}>
                                                    <Typography variant="h6" sx={{ mb: 1, color: 'black', fontWeight: 'bold', fontFamily: 'Times New Roman' }}>
                                                        Testing Options
                                                    </Typography>

                                                    <Stack direction="row" spacing={4} justifyContent="center" sx={{ ml: "10rem" }}>
                                                        <TextField
                                                            select
                                                            label="Category"
                                                            size="small"
                                                            value={form.category || ""}
                                                            onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                                                            sx={{ width: 200 }}
                                                            disabled={indenterIntervention || processOnHold}
                                                        >
                                                            <MenuItem value="">Select Category</MenuItem>
                                                            <MenuItem value="Mechanical">Mechanical</MenuItem>
                                                            <MenuItem value="Electrical">Electrical</MenuItem>
                                                            <MenuItem value="Electromechanical">Electromechanical</MenuItem>
                                                        </TextField>

                                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                                                            <Checkbox
                                                                checked={indenterIntervention}
                                                                onChange={(e) => {
                                                                    setIndenterIntervention(e.target.checked);
                                                                    setProcessOnHold(e.target.checked);
                                                                }}
                                                            />
                                                            <Typography style={{ fontFamily: 'Times New Roman', fontSize: '10' }}>Indenter Intervention Required</Typography>

                                                            {processOnHold && (
                                                                <Tooltip title="Process is on hold until indenter responds">
                                                                    <PauseCircleOutlineIcon color="warning" />
                                                                </Tooltip>
                                                            )}
                                                        </Box>
                                                    </Stack>
                                                </Grid>

                                                <Grid item xs={12}>
                                                    {!processOnHold && form.category && (
                                                        <Box sx={{ mt: 3 }}>
                                                            {form.category === "Mechanical" && (
                                                                <PhysicalForm sampleCount={15} onSummaryChange={setInspectionSummary} selectedRow={dimensiondata} Ref_no={referenceno} />
                                                            )}

                                                            {form.category === "Electrical" && (
                                                                <ElectricalForm onSummaryChange={setElectricalSummary} selectedRow={dimensiondata} sampleCount={15} Ref_no={referenceno} />
                                                            )}

                                                            {form.category === "Electromechanical" && (
                                                                <>
                                                                    <PhysicalForm sampleCount={15} onSummaryChange={setInspectionSummary} selectedRow={dimensiondata} Ref_no={referenceno} />
                                                                    <Box sx={{ mt: 4 }} />
                                                                    <ElectricalForm onSummaryChange={setElectricalSummary} selectedRow={dimensiondata} sampleCount={15} Ref_no={referenceno} />
                                                                </>
                                                            )}
                                                        </Box>
                                                    )}

                                                    <Divider sx={{ my: 1 }} />

                                                    {processOnHold && (
                                                        <Paper sx={{ mt: 2, p: 2, display: 'flex', gap: 2, alignItems: 'center' }}>
                                                            <PauseCircleOutlineIcon color="warning" sx={{ fontSize: 40 }} />
                                                            <Box>
                                                                <Typography variant="body1">
                                                                    Process is on hold awaiting indenter response.
                                                                </Typography>
                                                                <Typography variant="caption">
                                                                    Click resume to continue.
                                                                </Typography>

                                                                <Box sx={{ mt: 1 }}>
                                                                    <Button
                                                                        variant="contained"
                                                                        onClick={() => {
                                                                            setProcessOnHold(false);
                                                                            setIndenterIntervention(false);
                                                                        }}
                                                                    >
                                                                        Resume Process
                                                                    </Button>
                                                                </Box>
                                                            </Box>
                                                        </Paper>
                                                    )}
                                                </Grid>

                                               <Grid item xs={12}>
                                                    <Card
                                                        sx={{
                                                            p: 3,
                                                            borderRadius: 3,
                                                            boxShadow: "0px 6px 20px rgba(0,0,0,0.12)",
                                                            background: "linear-gradient(145deg, #e3f2fd, #ffffff)",
                                                        }}
                                                    >
                                                        <Typography
                                                            variant="h6"
                                                            sx={{
                                                                fontWeight: "bold",
                                                                mb: 2,
                                                                textAlign: "center",
                                                                color: "#0d47a1",
                                                                letterSpacing: 0.8,
                                                            }}
                                                        >
                                                            INSPECTION SUMMARY
                                                        </Typography>

                                                        <Box
                                                            sx={{
                                                                display: "flex",
                                                                flexWrap: "wrap",
                                                                justifyContent: "center",
                                                                gap: 3,
                                                                mt: 2,
                                                            }}
                                                        >
                                                            {/* Qty Received */}
                                                            <Card
                                                                sx={{
                                                                    p: 2,
                                                                    width: 200,
                                                                    borderRadius: 2,
                                                                    textAlign: "center",
                                                                    background: "white",
                                                                    boxShadow: "0px 4px 12px rgba(0,0,0,0.12)",
                                                                }}
                                                            >
                                                                <Typography sx={{ color: "#555", fontWeight: 600 }}>
                                                                    Qty Received
                                                                </Typography>
                                                                <Typography sx={{ fontWeight: 900, fontSize: 20, color: "#1b5e20" }}>
                                                                    {form.totalQty}
                                                                </Typography>
                                                            </Card>

                                                            {/* Qty Inspected */}
                                                            <Card
                                                                sx={{
                                                                    p: 2,
                                                                    width: 200,
                                                                    borderRadius: 2,
                                                                    textAlign: "center",
                                                                    background: "white",
                                                                    boxShadow: "0px 4px 12px rgba(0,0,0,0.12)",
                                                                }}
                                                            >
                                                                <Typography sx={{ color: "#555", fontWeight: 600 }}>
                                                                    Qty Inspected
                                                                </Typography>
                                                                <Typography sx={{ fontWeight: 900, fontSize: 20, color: "#0277bd" }}>
                                                                    {Number(inspectionSummary.accepted || 0) +
                                                                        Number(inspectionSummary.rejected || 0) +
                                                                        Number(electricalSummary.accepted || 0) +
                                                                        Number(electricalSummary.rejected || 0)}
                                                                </Typography>
                                                            </Card>

                                                            {/* Accepted */}
                                                            <Card
                                                                sx={{
                                                                    p: 2,
                                                                    width: 200,
                                                                    borderRadius: 2,
                                                                    textAlign: "center",
                                                                    background: "white",
                                                                    boxShadow: "0px 4px 12px rgba(0,0,0,0.12)",
                                                                }}
                                                            >
                                                                <Typography sx={{ color: "#555", fontWeight: 600 }}>
                                                                    Accepted
                                                                </Typography>
                                                                <Typography sx={{ fontWeight: 900, fontSize: 20, color: "#2e7d32" }}>
                                                                    {Number(inspectionSummary.accepted || 0) +
                                                                        Number(electricalSummary.accepted || 0)}
                                                                </Typography>
                                                            </Card>

                                                            {/* Rejected */}
                                                            <Card
                                                                sx={{
                                                                    p: 2,
                                                                    width: 200,
                                                                    borderRadius: 2,
                                                                    textAlign: "center",
                                                                    background: "white",
                                                                    boxShadow: "0px 4px 12px rgba(0,0,0,0.12)",
                                                                }}
                                                            >
                                                                <Typography sx={{ color: "#555", fontWeight: 600 }}>
                                                                    Rejected
                                                                </Typography>
                                                                <Typography sx={{ fontWeight: 900, fontSize: 20, color: "#c62828" }}>
                                                                    {Number(inspectionSummary.rejected || 0) +
                                                                        Number(electricalSummary.rejected || 0)}
                                                                </Typography>
                                                            </Card>
                                                        </Box>

                                                        {/* Remarks Box */}
                                                        <Box sx={{ mt: 4 }}>
                                                            <Typography sx={{ fontWeight: 700, mb: 1 }}>Remarks:</Typography>
                                                            <TextField
                                                                fullWidth
                                                                multiline
                                                                rows={3}
                                                                placeholder="Enter remarks here..."
                                                                sx={{
                                                                    background: "white",
                                                                    borderRadius: 2,
                                                                    "& .MuiOutlinedInput-root": {
                                                                        borderRadius: 2
                                                                    }
                                                                }}
                                                                value={report.remarks}
                                                                onChange={(e) =>
                                                                    setReport((prev) => ({ ...prev, remarks: e.target.value }))
                                                                }
                                                            />
                                                        </Box>
                                                    </Card>
                                                </Grid>

                                                {/* FULL INSPECTION & APPROVAL SECTION */}
                                                <Grid item xs={12}>
                                                <Card
                                                    sx={{
                                                        p: 3,
                                                        mt: 3,
                                                        borderRadius: 3,
                                                        boxShadow: "0px 6px 20px rgba(0,0,0,0.12)",
                                                        background: "linear-gradient(145deg, #ffffff, #f1f8ff)"
                                                    }}
                                                >
                                                    <Typography
                                                        variant="h6"
                                                        sx={{
                                                            fontWeight: 800,
                                                            textAlign: "center",
                                                            mb: 3,
                                                            color: "#0d47a1",
                                                            letterSpacing: 0.7
                                                        }}
                                                    >
                                                        INSPECTION & APPROVAL DETAILS
                                                    </Typography>

                                                    {/* ------------------------------- */}
                                                    {/* 1. INSPECTED BY SECTION          */}
                                                    {/* ------------------------------- */}
                                                    <Card
                                                        sx={{
                                                            p: 2,
                                                            mb: 3,
                                                            borderRadius: 2,
                                                            boxShadow: "0px 3px 10px rgba(0,0,0,0.12)",
                                                        }}
                                                    >
                                                        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 2 }}>
                                                            Inspected By
                                                        </Typography>

                                                        <Grid container spacing={2}>
                                                            {/* Staff ID */}
                                                            <Grid item xs={12} md={4}>
                                                                <TextField
                                                                    label="Staff ID"
                                                                    fullWidth
                                                                    value={form.inspectedBy}
                                                                    onChange={(e) =>
                                                                        setForm((f) => ({ ...f, inspectedBy: e.target.value }))
                                                                    }
                                                                />
                                                            </Grid>

                                                            {/* Date */}
                                                            <Grid item xs={12} md={4}>
                                                                <TextField
                                                                    type="date"
                                                                    label="Date"
                                                                    InputLabelProps={{ shrink: true }}
                                                                    fullWidth
                                                                    value={form.date}
                                                                    onChange={(e) =>
                                                                        setForm((f) => ({ ...f, date: e.target.value }))
                                                                    }
                                                                />
                                                            </Grid>

                                                            {/* Seal */}
                                                            <Grid item xs={12} md={4}>
                                                                <TextField
                                                                    label="Seal"
                                                                    fullWidth
                                                                    value="SCI-MCE Department"
                                                                    InputProps={{ readOnly: true }}
                                                                    sx={{ fontWeight: 700 }}
                                                                />
                                                            </Grid>
                                                        </Grid>
                                                    </Card>

                                                    {/* ------------------------------- */}
                                                    {/* 2. FOD CHECK                     */}
                                                    {/* ------------------------------- */}
                                                    <Card
                                                        sx={{
                                                            p: 2,
                                                            mb: 3,
                                                            borderRadius: 2,
                                                            boxShadow: "0px 3px 10px rgba(0,0,0,0.12)",
                                                        }}
                                                    >
                                                        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1 }}>
                                                            FOD Check
                                                        </Typography>

                                                        <Grid container spacing={2}>
                                                            <Grid item xs={12} md={4}>
                                                                <Checkbox
                                                                    checked={form.fodCheck || false}
                                                                    onChange={(e) =>
                                                                        setForm((f) => ({ ...f, fodCheck: e.target.checked }))
                                                                    }
                                                                />
                                                                <Typography component="span" sx={{ ml: 1 }}>
                                                                    FOD Check Completed
                                                                </Typography>
                                                            </Grid>

                                                            {/* Empty cells to maintain 4-4-4 structure */}
                                                            <Grid item xs={12} md={4}></Grid>
                                                            <Grid item xs={12} md={4}></Grid>
                                                        </Grid>
                                                    </Card>

                                                    {/* ------------------------------- */}
                                                    {/* 3. APPROVED BY SECTION           */}
                                                    {/* ------------------------------- */}
                                                    <Card
                                                        sx={{
                                                            p: 2,
                                                            borderRadius: 2,
                                                            boxShadow: "0px 3px 10px rgba(0,0,0,0.12)",
                                                        }}
                                                    >
                                                        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 2 }}>
                                                            Approved By
                                                        </Typography>

                                                        <Grid container spacing={2}>
                                                            {/* Name */}
                                                            <Grid item xs={12} md={4}>
                                                                <TextField
                                                                    label="Name"
                                                                    fullWidth
                                                                    InputProps={{ readOnly: true }}
                                                                />
                                                            </Grid>

                                                            {/* Digital Signature */}
                                                            <Grid item xs={12} md={4}>
                                                                <TextField
                                                                    label="Digital Signature"
                                                                    fullWidth
                                                                    value={form.approverSign || ""}
                                                                    onChange={(e) =>
                                                                        setForm((f) => ({ ...f, approverSign: e.target.value }))
                                                                    }
                                                                    placeholder="Enter or upload signature"
                                                                />
                                                            </Grid>

                                                            {/* Approval Date */}
                                                            <Grid item xs={12} md={4}>
                                                                <TextField
                                                                    type="date"
                                                                    label="Date"
                                                                    InputLabelProps={{ shrink: true }}
                                                                    fullWidth
                                                                    value={form.approvalDate || ""}
                                                                    onChange={(e) =>
                                                                        setForm((f) => ({ ...f, approvalDate: e.target.value }))
                                                                    }
                                                                />
                                                            </Grid>

                                                            {/* Seal */}
                                                            <Grid item xs={12} md={4}>
                                                                <TextField
                                                                    label="Seal"
                                                                    fullWidth
                                                                    value="SCI-MCE Department"
                                                                    InputProps={{ readOnly: true }}
                                                                />
                                                            </Grid>

                                                            {/* Fillers to maintain 4-4-4 layout */}
                                                            <Grid item xs={12} md={4}></Grid>
                                                            <Grid item xs={12} md={4}></Grid>
                                                        </Grid>
                                                    </Card>
                                                </Card>
                                            </Grid>

                                                <Grid item xs={12} sx={{ mt: 2 }}>
                                                    <Stack direction="row" justifyContent="center" spacing={2} >
                                                        <Button
                                                            fullWidth
                                                            variant="contained"
                                                            color="success"
                                                            onClick={() => handleOpenQr("accept")}
                                                            disabled={!form.partNumber}
                                                            style={{ width: '3rem' }}
                                                        >
                                                            <TaskAlt></TaskAlt><QrCode2></QrCode2>
                                                        </Button>
                                                        <Button
                                                            fullWidth
                                                            variant="contained"
                                                            color="error"
                                                            onClick={() => handleOpenQr("reject")}
                                                            disabled={!form.partNumber}
                                                            style={{ width: '3rem' }}
                                                        >
                                                            <HighlightOffIcon></HighlightOffIcon><QrCode2></QrCode2>
                                                        </Button>
                                                    </Stack>
                                                </Grid>
                                            </Grid>
                                        </Paper>
                                    </Grid>
                                </Grid>
                            </>
                        )}
                    </Box>

                    {qrOpen && (
                        <Paper sx={{ position: "fixed", bottom: 24, right: 24, p: 2 }}>
                            <Typography variant="subtitle1" sx={{ mb: 1 }}>{qrType === "accept" ? "Accept QR" : "Reject QR"}</Typography>
                            <Box sx={{ mb: 1 }}>
                                <QRCodeSVG value={qrPayload} />
                            </Box>
                            <Button variant="contained" onClick={handleCloseQr}>Close</Button>
                        </Paper>
                    )}
                </CardContent>
            </Card>
        </Box>
    );
}
