// import { Divider, Typography } from "@mui/material";
// import React, { useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { useNavigate } from "react-router";

// import { login } from "../../Redux/Actions/authUser";

// function LoginPage(props) {
//   const [company, setCompany] = useState('');
//   const [sbu, setSbu] = useState('');
//   const [subdivision, setSubdivision] = useState('');

//   const companies = ['BEL', 'CMTI', 'DRDO'];
//   const sbus = ['MILCOM', 'SEMICONDUCTOR', 'SOFTWARE'];
//   const subdivisions = ['IG STORE', 'SUB CONTRACT INSPECTION', 'MATERIAL INSPECTION'];


//   const handleCompanyChange = (event) => {
//     setCompany(event.target.value);
 
//   };

//   const handleSbuChange = (event) => {
//     setSbu(event.target.value);
//   };

//   const handleSubdivisionChange = (event) => {
//     setSubdivision(event.target.value);
//   };

//   const UserMessage = useSelector((state) => state.AuthUserReducer.UserMessage);

//   const configDetails = useSelector(state => state.MROTDataSavingReducer.configDetails)
//   //var ServerIP = 'http://192.168.0.20:8081/auth/'

//   var ServerIP = 'http://127.0.0.1:8081/auth/'
//   if (configDetails != undefined) {

//     if (configDetails.project[0].ServerIP != undefined) {


//       if (configDetails.project[0].ServerIP[0].NodeServerIP != undefined) {

//         ServerIP = configDetails.project[0].ServerIP[0].NodeServerIP + "/auth/"

//       }


//     }

//   }



//   const navigate = useNavigate();
//   const dispatch = useDispatch();

//   const [Login, setlogin] = useState(false);
//   var CryptoJS = require("crypto-js");

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     // console.log(e.target.userID.value);

//     if (!e.target.userID.value) {
//       alert("User ID is required");
//     } else if (!e.target.userID.value) {
//       alert("Valid User ID is required");
//     } else if (!e.target.password.value) {
//       alert("Password is required");
//     } else if (
//       e.target.userID.value === "lynx@bel.co.in" &&
//       e.target.password.value === "lynx"
//     ) {
//       setlogin(true);
//       //   alert("Successfully logged in");
//       // {
//       //   props.logedIn(true);
//       // }
//       {
//         props.logedIn(true);
//       }
//       navigate("/Main/MES");
//       e.target.userID.value = "";
//       e.target.password.value = "";
//     }
//     //  else {
//     //   setlogin(false);
//     //   alert("Wrong email or password combination");
//     // }
//     else {
//       // var cipherpassword = CryptoJS.AES.encrypt(JSON.stringify(e.target.password.value), config.secret).toString();
//       if (true) {
//         dispatch(login(e.target.userID.value, e.target.password.value, ServerIP))
//           .then((res) => {
//             // props.history.push("/profile");

//             navigate("/Main/MES");
//             // window.location.reload();
//           })
//           .catch((err) => {
//             // console.log("Error while Logged in");
//             // console.log("Error while Logged in", err);

//             // setLoading(false);
//           });
//       } else {
//         // setLoading(false);
//       }
//     }
//   };

//   const handleClick = (e) => {
//     e.preventDefault();
//     // navigate('/Main');
//     alert("Goes to registration page");
//   };


//   const handleChange = (e) => {
//     console.log("e", e.target.value)
//   }
//   return (
//     <div className="mainApp">
//       <div className="rootApp">
//         <div className="App">
//           <Typography
//             gutterBottom
//             variant="h3"
//             component="div"
//             style={{ color: "#ac1717", paddingTop: "20px" }}
//           >
//             INDUSTRY 4.0
//           </Typography>
//           <Divider style={{ backgroundColor: "red", fontSize: "5px" }} />
//           <form className="form" onSubmit={handleSubmit}>
//           <div className="input-group">
//               <label htmlFor="company">Company:</label>
//               <select value={company} onChange={handleCompanyChange} style={{ width: '70%', padding: '8px', borderRadius: '5px',backgroundColor:'white' }}>
//                 <option value="">Select Company</option>
//                 {companies.map((comp) => (
//                   <option key={comp} value={comp}>
//                     {comp}
//                   </option>
//                 ))}
//               </select>
//             </div>

//             <div className="input-group">
//               <label htmlFor="sbu">SBU:</label>
//               <select value={sbu} onChange={handleSbuChange} style={{ width: '70%', padding: '8px', borderRadius: '5px',backgroundColor:'white' }}>
//                 <option value="">Select SBU</option>
//                 {sbus.map((s) => (
//                   <option key={s} value={s}>
//                     {s}
//                   </option>
//                 ))}
//               </select>
//             </div>

//             <div className="input-group">
//               <label htmlFor="subdivision">Subdivision:</label>
//               <select value={subdivision} onChange={handleSubdivisionChange} style={{ width: '70%', padding: '8px', borderRadius: '5px',backgroundColor:'white' }}>
//                 <option value="">Select Subdivision</option>
//                 {subdivisions.map((sub) => (
//                   <option key={sub} value={sub}>
//                     {sub}
//                   </option>
//                 ))}
//               </select>
//             </div>
//             <div className="input-group">
//               <label htmlFor="userID">User ID</label>
//               <input
//                 // type="email"
//                 name="userID"
//                 placeholder="userID"
//               />
//             </div>
//             <div className="input-group">
//               <label htmlFor="password">Password</label>
//               <input type="password" name="password" />
//             </div>



//             <button className="primary" style={{ width: '10rem' }}>Login</button>
//           </form>

//           <label className="logo" style={{ color: "red" }}>
//             {UserMessage}
//           </label>
//           <br></br>


//         </div>
//       </div>
//     </div>
//   );
// }

// export default LoginPage;




import { Divider, Typography } from "@mui/material";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router";
import { login } from "../../Redux/Actions/authUser";

function LoginPage(props) {
  const [company, setCompany] = useState('BEL');
  const [sbu, setSbu] = useState('');
  const [subdivision, setSubdivision] = useState('');

  const companies = ['BEL', 'BDL'];
  const sbus = ['MILCOM', 'COMPONENTS'];
  const subdivisions = ['IG STORE', 'SUB CONTRACT INSPECTION', 'MATERIAL INSPECTION'];

  const handleCompanyChange = (event) => setCompany(event.target.value);
  const handleSbuChange = (event) => setSbu(event.target.value);
  const handleSubdivisionChange = (event) => setSubdivision(event.target.value);

  const UserMessage = useSelector((state) => state.AuthUserReducer.UserMessage);
  const configDetails = useSelector(state => state.MROTDataSavingReducer.configDetails);

  var ServerIP = 'http://127.0.0.1:8082/auth/';
  if (configDetails?.project?.[0]?.ServerIP?.[0]?.NodeServerIP) {
    ServerIP = configDetails.project[0].ServerIP[0].NodeServerIP + "/auth/";
  }

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [Login, setlogin] = useState(false);
  var CryptoJS = require("crypto-js");

  // const handleSubmit = (e) => {
  //   e.preventDefault();

  //   if (!e.target.userID.value) {
  //     alert("User ID is required");
  //   } else if (!e.target.password.value) {
  //     alert("Password is required");
  //   } 
  //   else if (
  //     e.target.userID.value === "lynx@bel.co.in" &&
  //     e.target.password.value === "lynx"
  //   ) {
  //     setlogin(true);
  //     props.logedIn(true);
  //     navigate("/Main/MES");
  //     e.target.userID.value = "";
  //     e.target.password.value = "";
  //   } else {
  //     dispatch(login(e.target.userID.value, e.target.password.value, ServerIP))
  //       .then(() => navigate("/Main/MES"))
  //       .catch(() => {});
  //   }
  // };


  const handleSubmit = (e) => {
    e.preventDefault();
  
    const userID = e.target.userID.value;
    const password = e.target.password.value;
  
    // Validate fields
    if (!company) {
      alert("Please select a company");
      return;
    }
    if (!sbu) {
      alert("Please select an SBU");
      return;
    }
    if (!subdivision) {
      alert("Please select a subdivision");
      return;
    }
    if (!userID) {
      alert("User ID is required");
      return;
    }
    if (!password) {
      alert("Password is required");
      return;
    }
  
    // Hardcoded login
    if (userID === "lynx@bel.co.in" && password === "lynx") {
      setlogin(true);
      props.logedIn(true);
      navigate("/Main/MES");
      return;
    }
  
    // Normal login — Send company, sbu, subdivision
    dispatch(login(userID, password, ServerIP, company, sbu, subdivision))
      .then(() => navigate("/Main/MES"))
      .catch(() => {});
  };
  
  
  return (
    <div className="mainApp">
      <div className="rootApp">
        <div className="login-card">
          <Typography
            gutterBottom
            variant="h3"
            component="div"
            style={{ color: "white", paddingTop: "20px",fontFamily:'Times New Roman' }}
            // sx={{ fontWeight: "bold", mb: 1,fontFamily:'Times New Roman',color:'#0d47a1' }}

          >
            INDUSTRY 4.0
          </Typography>
          <Divider style={{ backgroundColor: "white", fontSize: "5px" }} />
          <form className="form" onSubmit={handleSubmit}>
            <div className="input-group">
              <label htmlFor="company">Company:</label>
              <select value={company} onChange={handleCompanyChange}>
                <option value="">Select Company</option>
                {companies.map((comp) => (
                  <option key={comp} value={comp}>
                    {comp}
                  </option>
                ))}
              </select>
            </div>

            <div className="input-group">
              <label htmlFor="sbu">SBU:</label>
              <select value={sbu} onChange={handleSbuChange}>
                <option value="">Select SBU</option>
                {sbus.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            <div className="input-group">
              <label htmlFor="subdivision">Subdivision:</label>
              <select value={subdivision} onChange={handleSubdivisionChange}>
                <option value="">Select Subdivision</option>
                {subdivisions.map((sub) => (
                  <option key={sub} value={sub}>
                    {sub}
                  </option>
                ))}
              </select>
            </div>

            <div className="input-group">
              <label htmlFor="userID">User ID</label>
              <input name="userID" placeholder="userID" />
            </div>

            <div className="input-group">
              <label htmlFor="password">Password</label>
              <input type="password" name="password" />
            </div>

            <button className="primary" style={{ width: '10rem' }}>Login</button>
          </form>

          <label className="logo" style={{ color: "red" }}>
            {UserMessage}
          </label>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
