import React, { useEffect, useMemo, useState } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import CryptoJS from "crypto-js";
import {
  Box,
  Card,
  CardContent,
  Grid,
  Tab,
  Tabs,
  TextField,
  Typography,
  Button,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Divider,
  Stack,
} from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import DeleteIcon from "@mui/icons-material/Delete";
import SaveIcon from "@mui/icons-material/Save";
import EditIcon from "@mui/icons-material/Edit";
import ListIcon from "@mui/icons-material/List";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import { saveUserProfileData, UpdateUserProfileData, DeleteUserProfileData } from "../../Redux/Actions/UserProfileAction";
import { styled } from "@mui/material/styles";

const UserRole = [
  "System Operator",
  "System Supervisor External",
  "System Supervisor Internal",
  "System Officer",
  "Administrator",
];
const AdminRole = ["Yes", "No"];

const Title = ({ children }) => (
  <Typography sx={{ fontWeight: 800, mb: 2, color: "#0d47a1" }}>{children}</Typography>
);

const CardWrapper = ({ children }) => (
  <Card sx={{ borderRadius: 2, boxShadow: 3, mb: 3 }}>
    <CardContent>{children}</CardContent>
  </Card>
);

function TabPanel({ value, index, children }) {
  return value === index ? <Box sx={{ py: 1 }}>{children}</Box> : null;
}

function UserManagement(props) {
  const dispatch = useDispatch();
  const UserProfileData = useSelector((s) => s.MROTDataSavingReducer.UserProfileData || {});
  const configDetails = useSelector((s) => s.MROTDataSavingReducer.configDetails);
  const submitStatus = useSelector((s) => s.MROTDataSavingReducer.submitStatus);

  const ServerIP = configDetails?.project?.[0]?.ServerIP?.[0]?.NodeServerIP || "http://127.0.0.1:8081";

  const [tabIndex, setTabIndex] = useState(0);
  const [message, setMessage] = useState("");
  const [tableRows, setTableRows] = useState([]);
  const [selectedForUpdate, setSelectedForUpdate] = useState(null);
  const [selectedForDelete, setSelectedForDelete] = useState(null);

  // Create form
  const { register, handleSubmit, reset, formState: { errors }, trigger } = useForm();

  // Update form (separate instance)
  const {
    register: registerUpd,
    handleSubmit: handleSubmitUpd,
    reset: resetUpd,
    setValue: setValueUpd,
    formState: { errors: errorsUpd },
  } = useForm();

  // Delete does not need hook form.

  useEffect(() => {
    if (submitStatus) {
      setMessage(submitStatus);
      setTimeout(() => setMessage(""), 6000);
    }
  }, [submitStatus]);

  // Keep tableRows in sync with Redux payload shape similar to your previous code
  useEffect(() => {
    if (UserProfileData?.users && Array.isArray(UserProfileData.users)) {
      const headers = UserProfileData.users[0];
      const dataRows = UserProfileData.users.slice(1);
      const final = dataRows.map((row) => {
        const obj = {};
        headers.forEach((h, i) => (obj[h] = row[i]));
        return obj;
      });
      setTableRows(final);
    } else {
      setTableRows([]);
    }
  }, [UserProfileData]);

  // Helper: encrypt password
  const encryptPassword = (pwd) => CryptoJS.AES.encrypt(JSON.stringify(pwd), config.secret).toString();

  // Helper: decrypt password (used for update form display)
  const decryptPassword = (ciphertext) => {
    try {
      const bytes = CryptoJS.AES.decrypt(ciphertext, config.secret);
      return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    } catch {
      return "";
    }
  };

  // CREATE handler
  const onCreate = (data) => {
    if (data.password !== data.confirmpassword) {
      setMessage("Password & Confirm Password do not match");
      return;
    }

    const admin = data.role === "Administrator" ? "Yes" : "No";
    const payload = {
      userid: data.userid,
      username: data.username,
      company: data.company,
      sbu: data.sbu,
      subdivision: data.subdivision,
      role: data.role,
      description: data.description,
      password: encryptPassword(data.password),
      admin,
    };

    dispatch(saveUserProfileData(payload, ServerIP));
    reset();
  };

  // PREPARE UPDATE: fill update form when row selected
  const prepareUpdate = (row) => {
    setSelectedForUpdate(row);
    setTabIndex(1); // switch to Update tab
    // populate update form fields
    setValueUpd("userid", row.userid || row.id || "");
    setValueUpd("username", row.username || row.name || "");
    setValueUpd("company", row.company || "");
    setValueUpd("sbu", row.sbu || "");
    setValueUpd("subdivision", row.subdivision || "");
    setValueUpd("role", row.role || "");
    setValueUpd("admin", row.admin || "");
    setValueUpd("description", row.description || "");
    setValueUpd("password", decryptPassword(row.password || "") || "");
    setValueUpd("confirmpassword", decryptPassword(row.password || "") || "");
  };

  // UPDATE handler
  const onUpdate = (data) => {
    if (data.password !== data.confirmpassword) {
      setMessage("Password & Confirm Password do not match");
      return;
    }

    const payload = {
      ...data,
      password: encryptPassword(data.password),
    };

    dispatch(UpdateUserProfileData(payload, ServerIP));
    setSelectedForUpdate(null);
    resetUpd();
  };

  // DELETE handler
  const doDelete = () => {
    if (!selectedForDelete) {
      setMessage("Select a user to delete");
      return;
    }

    // payload shape same as earlier DeleteUserProfileData expects an array of user objects
    dispatch(DeleteUserProfileData([selectedForDelete], ServerIP));
    setSelectedForDelete(null);
  };

  // Tab change
  const handleTabChange = (_, newIndex) => {
    setTabIndex(newIndex);
  };

  // memoized userIds for selects
  const userIds = useMemo(() => tableRows.map((r) => r.userid || r.id).filter(Boolean), [tableRows]);

  // styles
  const leftCol = { xs: 12, md: 6 };

  return (
    <Box sx={{ p: { xs: 1, md: 4 }, maxWidth: 1200, mx: "auto" }}>
      <CardWrapper>
        <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
          <Stack direction="row" alignItems="center" spacing={1}>
            <ListIcon color="primary" />
            <Typography variant="h5" sx={{ fontWeight: 800 }}>
              User Profile Management
            </Typography>
          </Stack>
          <Typography variant="caption" color="text.secondary">
            Secure · Role-based · Audit-ready
          </Typography>
        </Stack>

        <Tabs value={tabIndex} onChange={handleTabChange} variant="fullWidth" centered>
          <Tab icon={<PersonAddIcon />} label="Create" />
          <Tab icon={<EditIcon />} label="Update" />
          <Tab icon={<DeleteIcon />} label="Delete" />
          <Tab icon={<ListIcon />} label="List" />
        </Tabs>

        <Divider sx={{ my: 2 }} />

        {/* ---------- CREATE TAB ---------- */}
        <TabPanel value={tabIndex} index={0}>
          <Grid container spacing={2}>
            <Grid item {...leftCol}>
              <CardWrapper>
                <Title>Create New User</Title>
                <form onSubmit={handleSubmit(onCreate)}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        label="Company Name"
                        fullWidth
                        {...register("company", { required: "Company is required", pattern: { value: /^[A-Za-z ]+$/, message: "Letters only" } })}
                        error={!!errors.company}
                        helperText={errors.company?.message}
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        label="User ID"
                        fullWidth
                        {...register("userid", { required: "User ID required", pattern: { value: /^[A-Za-z]+[0-9]+$/, message: "Letters followed by numbers" } })}
                        error={!!errors.userid}
                        helperText={errors.userid?.message}
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        label="User Name"
                        fullWidth
                        {...register("username", { required: "User Name required" })}
                        error={!!errors.username}
                        helperText={errors.username?.message}
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        select
                        label="User Role"
                        fullWidth
                        defaultValue=""
                        {...register("role", { required: "Role required" })}
                        error={!!errors.role}
                        helperText={errors.role?.message}
                      >
                        {UserRole.map((r) => <MenuItem key={r} value={r}>{r}</MenuItem>)}
                      </TextField>
                    </Grid>
                  </Grid>

                  <Box sx={{ mt: 2, display: "flex", gap: 2, justifyContent: "flex-end" }}>
                    <Button type="submit" variant="contained" startIcon={<SaveIcon />} color="primary">Create</Button>
                  </Box>
                </form>
              </CardWrapper>
            </Grid>

            <Grid item {...leftCol}>
              <CardWrapper>
                <Title>Security & Organization</Title>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      label="SBU Name"
                      fullWidth
                      {...register("sbu", { required: "SBU required" })}
                      error={!!errors.sbu}
                      helperText={errors.sbu?.message}
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      label="Subdivision"
                      fullWidth
                      {...register("subdivision", { required: "Subdivision required" })}
                      error={!!errors.subdivision}
                      helperText={errors.subdivision?.message}
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      label="Password"
                      type="password"
                      fullWidth
                      {...register("password", { required: "Password required" })}
                      error={!!errors.password}
                      helperText={errors.password?.message}
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      label="Confirm Password"
                      type="password"
                      fullWidth
                      {...register("confirmpassword", { required: "Confirm password required" })}
                      error={!!errors.confirmpassword}
                      helperText={errors.confirmpassword?.message}
                    />
                  </Grid>

                  <Grid item xs={12}>
                    <TextField
                      label="Description"
                      fullWidth
                      multiline
                      rows={2}
                      {...register("description")}
                    />
                  </Grid>
                </Grid>
              </CardWrapper>
            </Grid>
          </Grid>

          {message && <Typography color="success.main" sx={{ mt: 1 }}>{message}</Typography>}
        </TabPanel>

        {/* ---------- UPDATE TAB ---------- */}
        <TabPanel value={tabIndex} index={1}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <CardWrapper>
                <Title>Select User to Edit</Title>
                <TextField
                  select
                  fullWidth
                  label="Select User"
                  value={selectedForUpdate ? (selectedForUpdate.userid || selectedForUpdate.id) : ""}
                  onChange={(e) => {
                    const uid = e.target.value;
                    const row = tableRows.find(r => (r.userid || r.id) === uid);
                    if (row) prepareUpdate(row);
                  }}
                >
                  <MenuItem value="">-- Select --</MenuItem>
                  {userIds.map((id) => <MenuItem key={id} value={id}>{id}</MenuItem>)}
                </TextField>

                <Divider sx={{ my: 2 }} />

                <Typography variant="body2" color="text.secondary">Tip: selecting a user populates the right-hand edit form.</Typography>
              </CardWrapper>
            </Grid>

            <Grid item xs={12} md={8}>
              <CardWrapper>
                <Title>Edit User</Title>

                <form onSubmit={handleSubmitUpd(onUpdate)} noValidate>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <TextField fullWidth label="User ID" {...registerUpd("userid", { required: true })} error={!!errorsUpd.userid} />
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <TextField fullWidth label="User Name" {...registerUpd("username", { required: true })} error={!!errorsUpd.username} />
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <TextField fullWidth label="Company" {...registerUpd("company")} />
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <TextField select fullWidth label="Role" {...registerUpd("role")}>
                        {UserRole.map(r => <MenuItem key={r} value={r}>{r}</MenuItem>)}
                      </TextField>
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <TextField fullWidth label="SBU" {...registerUpd("sbu")} />
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <TextField fullWidth label="Subdivision" {...registerUpd("subdivision")} />
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <TextField fullWidth label="Password" type="password" {...registerUpd("password")} />
                    </Grid>

                    <Grid item xs={12} md={6}>
                      <TextField fullWidth label="Confirm Password" type="password" {...registerUpd("confirmpassword")} />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField fullWidth multiline rows={2} label="Description" {...registerUpd("description")} />
                    </Grid>
                  </Grid>

                  <Box sx={{ mt: 2, display: "flex", justifyContent: "flex-end" }}>
                    <Button type="submit" startIcon={<EditIcon />} variant="contained">Save Changes</Button>
                  </Box>
                </form>
              </CardWrapper>
            </Grid>
          </Grid>

          {message && <Typography color="success.main" sx={{ mt: 1 }}>{message}</Typography>}
        </TabPanel>

        {/* ---------- DELETE TAB ---------- */}
        <TabPanel value={tabIndex} index={2}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <CardWrapper>
                <Title>Delete User</Title>
                <TextField
                  select
                  fullWidth
                  label="Select User to Delete"
                  value={selectedForDelete ? (selectedForDelete.userid || selectedForDelete.id) : ""}
                  onChange={(e) => {
                    const uid = e.target.value;
                    const row = tableRows.find(r => (r.userid || r.id) === uid);
                    setSelectedForDelete(row || null);
                  }}
                >
                  <MenuItem value="">-- Select --</MenuItem>
                  {userIds.map((id) => <MenuItem key={id} value={id}>{id}</MenuItem>)}
                </TextField>

                <Divider sx={{ my: 2 }} />

                <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 2 }}>
                  <Button color="error" variant="contained" startIcon={<DeleteIcon />} onClick={doDelete}>Delete</Button>
                </Box>
              </CardWrapper>
            </Grid>

            <Grid item xs={12} md={6}>
              <CardWrapper>
                <Title>Preview</Title>
                {selectedForDelete ? (
                  <Box>
                    <Typography><strong>User ID:</strong> {selectedForDelete.userid || selectedForDelete.id}</Typography>
                    <Typography><strong>Name:</strong> {selectedForDelete.username || selectedForDelete.name}</Typography>
                    <Typography><strong>Role:</strong> {selectedForDelete.role}</Typography>
                    <Typography><strong>Company:</strong> {selectedForDelete.company}</Typography>
                    <Typography sx={{ mt: 1, color: "text.secondary" }}>{selectedForDelete.description}</Typography>
                  </Box>
                ) : (
                  <Typography color="text.secondary">Select a user to preview details before deleting.</Typography>
                )}
              </CardWrapper>
            </Grid>
          </Grid>
        </TabPanel>

        {/* ---------- LIST TAB ---------- */}
        <TabPanel value={tabIndex} index={3}>
          <CardWrapper>
            <Title>All Users</Title>
            <TableContainer component={Paper} variant="outlined">
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ background: "#f3f6fb" }}>
                    <TableCell><strong>User ID</strong></TableCell>
                    <TableCell><strong>Name</strong></TableCell>
                    <TableCell><strong>Company</strong></TableCell>
                    <TableCell><strong>SBU</strong></TableCell>
                    <TableCell><strong>Subdivision</strong></TableCell>
                    <TableCell><strong>Role</strong></TableCell>
                    <TableCell><strong>Admin</strong></TableCell>
                    <TableCell align="right"><strong>Actions</strong></TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {tableRows.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} align="center" sx={{ py: 3 }}>No users found.</TableCell>
                    </TableRow>
                  ) : tableRows.map((row, idx) => (
                    <TableRow key={idx} hover>
                      <TableCell>{row.userid || row.id}</TableCell>
                      <TableCell>{row.username || row.name}</TableCell>
                      <TableCell>{row.company}</TableCell>
                      <TableCell>{row.sbu}</TableCell>
                      <TableCell>{row.subdivision}</TableCell>
                      <TableCell>{row.role}</TableCell>
                      <TableCell>{row.admin}</TableCell>
                      <TableCell align="right">
                        <Stack direction="row" spacing={1} justifyContent="flex-end">
                          <Button size="small" variant="outlined" startIcon={<EditIcon />} onClick={() => prepareUpdate(row)}>Edit</Button>
                          <Button size="small" color="error" variant="outlined" startIcon={<DeleteIcon />} onClick={() => setSelectedForDelete(row)}>Delete</Button>
                        </Stack>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardWrapper>
        </TabPanel>
      </CardWrapper>
    </Box>
  );
}

function mapStateToProps(state) {
  return {
    status: state.MROTDataSavingReducer.submitStatus,
    updatestatus: state.MROTDataSavingReducer.updateStatus,
  };
}

export default connect(mapStateToProps)(UserManagement);
