// UserProfileMain.jsx
import React from "react";
import PropTypes from "prop-types";
import { connect, useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { useTheme } from "@mui/material/styles";
import SwipeableViews from "react-swipeable-views";
import {
  Box,
  AppBar,
  Tabs,
  Tab,
  Typography,
  Container,
  Paper,
  Toolbar,
  IconButton,
} from "@mui/material";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import ListAltIcon from "@mui/icons-material/ListAlt";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import MenuIcon from "@mui/icons-material/Menu";
import { logout } from "../../Redux/Actions/authUser";
import { getSubmitStatus, getUserProfileData } from "../../Redux/Actions/UserProfileAction";
import authHeader from "../../Services/auth-header";
import UserProfile, { DeleteUserProfile, UpdateProfile, UserProfileCustomizedTables } from "./UserProfile";
import CustomHeader from '../../CommonComponents/Header/CustomHeader';

function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: { xs: 1, md: 3 } }}>
          <Typography component="div">{children}</Typography>
        </Box>
      )}
    </div>
  );
}
TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `full-width-tab-${index}`,
    "aria-controls": `full-width-tabpanel-${index}`,
  };
}

function UserProfileMain(props) {
  const theme = useTheme();
  const dispatch = useDispatch();

  // configDetails from store to derive NodeServerIP
  const configDetails = useSelector((state) => state.MROTDataSavingReducer.configDetails);
  const NodeServerIP =
    configDetails?.project?.[0]?.ServerIP?.[0]?.NodeServerIP || "http://127.0.0.1:8081";

  const [value, setValue] = React.useState(0);
  const [recallStatus, setRecallStatus] = React.useState(false);

  const UserProfileData = useSelector((state) => state.MROTDataSavingReducer.UserProfileData);
  const { user: currentUser } = useSelector((state) => state.AuthUserReducer);

  React.useEffect(() => {
    // fetch on mount and when recallStatus or tab changes
    const fetchUsers = async () => {
      try {
        const res = await axios.get(`${NodeServerIP}/users`, { headers: authHeader() });
        if (res?.data) {
          dispatch(getUserProfileData(res.data));
        }
      } catch (err) {
        if (err?.response?.status === 401 || err?.response?.status === 403) {
          alert("You are Unauthorized");
          dispatch(getSubmitStatus("You are Unauthorized"));
          if (currentUser != null) dispatch(logout(currentUser.id));
        } else {
          dispatch(getSubmitStatus("Not Submitted Successfully"));
        }
      }
    };

    fetchUsers();
    // reset recall flag after fetch
    if (recallStatus) setRecallStatus(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recallStatus, value, dispatch, NodeServerIP]);

  const recall = (status) => setRecallStatus(Boolean(status));

  const handleChange = (event, newValue) => setValue(newValue);
  const handleChangeIndex = (index) => setValue(index);

  // UI: nice tab label with icon + text
  const TabLabel = ({ icon, label }) => (
    <Box sx={{ display: "flex", gap: 1, alignItems: "center", px: 1 }}>
      {icon}
      <Typography sx={{ fontWeight: 700, fontSize: { xs: 12, md: 14 } }}>{label}</Typography>
    </Box>
  );

  // Access control: if not logged in, reload; if not admin, show not authorized
  if (!currentUser) {
    // avoid infinite reload loops in dev — keep same behavior as original (but more graceful)
    // Attempt a reload once; if still null, show message
    if (typeof window !== "undefined" && !window._userProfileReloaded) {
      window._userProfileReloaded = true;
      window.location.reload();
      return null;
    }
    return (
      <Container sx={{ py: 6 }}>
        <Paper sx={{ p: 4, textAlign: "center" }}>
          <Typography variant="h6">Preparing environment... please wait.</Typography>
        </Paper>
      </Container>
    );
  }

  // Admin view
  const isAdmin = currentUser.admin === "Yes" || currentUser.userRole === "Administrator";

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "background.default", pb: 6 }}>
      <CustomHeader header={"MROT: User Profile Management"} path={props.path} />

      <Container maxWidth="lg" sx={{ mt: 3 }}>
        <Paper
          elevation={6}
          sx={{
            borderRadius: 3,
            overflow: "hidden",
            boxShadow: "0 8px 30px rgba(2, 6, 23, 0.08)",
          }}
        >
          <Toolbar
            disableGutters
            sx={{
              px: { xs: 2, md: 3 },
              py: { xs: 1.5, md: 2 },
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              bgcolor: "background.paper",
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <IconButton edge="start" color="inherit" aria-label="menu" size="large">
                <MenuIcon />
              </IconButton>
              <Box>
                <Typography variant="h5" sx={{ fontWeight: 800 }}>
                  User Profiles
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Create · View · Update · Delete users
                </Typography>
              </Box>
            </Box>

            <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
              <Typography variant="body2" color="text.secondary">
                Signed in: <strong style={{ color: "#0d47a1" }}>{currentUser.username || currentUser.id}</strong>
              </Typography>
            </Box>
          </Toolbar>

          {/* Tabs */}
          <AppBar position="static" elevation={0} sx={{ bgcolor: "transparent", boxShadow: "none" }}>
            <Tabs
              value={value}
              onChange={handleChange}
              variant="fullWidth"
              textColor="inherit"
              TabIndicatorProps={{
                style: {
                  display: "flex",
                  justifyContent: "center",
                  backgroundColor: "transparent",
                },
              }}
              sx={{
                "& .MuiTabs-flexContainer": { gap: 1, px: { xs: 1, md: 3 } },
                "& .MuiTab-root": {
                  minHeight: 56,
                  borderRadius: 2,
                  textTransform: "none",
                  margin: 1,
                },
                p: { xs: 1, md: 2 },
                bgcolor: "background.default",
              }}
            >
              <Tab
                label={<TabLabel icon={<PersonAddIcon />} label="Create User" />}
                {...a11yProps(0)}
                sx={{
                  bgcolor: value === 0 ? "primary.main" : "transparent",
                  color: value === 0 ? "white" : "text.primary",
                }}
              />
              <Tab
                label={<TabLabel icon={<ListAltIcon />} label="Show All Users" />}
                {...a11yProps(1)}
                sx={{
                  bgcolor: value === 1 ? "primary.main" : "transparent",
                  color: value === 1 ? "white" : "text.primary",
                }}
              />
              <Tab
                label={<TabLabel icon={<EditIcon />} label="Update Users" />}
                {...a11yProps(2)}
                sx={{
                  bgcolor: value === 2 ? "primary.main" : "transparent",
                  color: value === 2 ? "white" : "text.primary",
                }}
              />
              <Tab
                label={<TabLabel icon={<DeleteIcon />} label="Delete Users" />}
                {...a11yProps(3)}
                sx={{
                  bgcolor: value === 3 ? "primary.main" : "transparent",
                  color: value === 3 ? "white" : "text.primary",
                }}
              />
            </Tabs>
          </AppBar>

          {/* Content area — keep SwipeableViews for mobile-friendly swiping */}
          <Box sx={{ bgcolor: "background.paper", p: { xs: 1, md: 3 } }}>
            {isAdmin ? (
              <SwipeableViews
                axis={theme.direction === "rtl" ? "x-reverse" : "x"}
                index={value}
                onChangeIndex={handleChangeIndex}
                resistance
              >
                <TabPanel value={value} index={0} dir={theme.direction}>
                  <Paper sx={{ p: 2, borderRadius: 2 }}>
                    <UserProfile path={props.path} recall={recall} />
                  </Paper>
                </TabPanel>

                <TabPanel value={value} index={1} dir={theme.direction}>
                  <Paper sx={{ p: 2, borderRadius: 2 }}>
                    {UserProfileData && <UserProfileCustomizedTables data={UserProfileData} />}
                  </Paper>
                </TabPanel>

                <TabPanel value={value} index={2} dir={theme.direction}>
                  <Paper sx={{ p: 2, borderRadius: 2 }}>
                    {UserProfileData && <UpdateProfile status={props.updatestatus} recall={recall} />}
                  </Paper>
                </TabPanel>

                <TabPanel value={value} index={3} dir={theme.direction}>
                  <Paper sx={{ p: 2, borderRadius: 2 }}>
                    {UserProfileData && <DeleteUserProfile data={UserProfileData} status={props.deletestatus} recall={recall} />}
                  </Paper>
                </TabPanel>
              </SwipeableViews>
            ) : (
              <Box sx={{ textAlign: "center", py: 6 }}>
                <Typography variant="h6" color="text.secondary">
                  You are not authorized to view this page.
                </Typography>
              </Box>
            )}
          </Box>
        </Paper>
      </Container>
    </Box>
  );
}

function mapStateToProps(state) {
  return {
    deletestatus: state.MROTDataSavingReducer.deleteStatus,
    updatestatus: state.MROTDataSavingReducer.updateStatus,
  };
}

export default connect(mapStateToProps)(UserProfileMain);
